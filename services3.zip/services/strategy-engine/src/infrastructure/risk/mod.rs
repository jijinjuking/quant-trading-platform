//! # 风控基础设施 (Risk Infrastructure) - v1 占位骨架
//!
//! 提供 RiskPort 的具体实现。

/// Noop 风控 - 占位实现
pub mod noop_risk;

pub use noop_risk::NoopRisk;
