//! # Mock 风控适配器 (Mock Risk Adapter)
//!
//! 路径: services/trading-engine/src/infrastructure/risk/mock_risk_adapter.rs
//!
//! ## 职责
//! 用于测试的 Mock 风控适配器，不依赖远程服务。
//! 实现基本的风控规则用于单元测试。
//!
//! ## 注意
//! 此适配器仅用于测试，生产环境应使用 RemoteRiskAdapter。

use std::collections::{HashMap, HashSet};
use std::sync::RwLock;

use anyhow::Result;
use async_trait::async_trait;
use rust_decimal::Decimal;

use crate::domain::model::order_intent::OrderIntent;
use crate::domain::port::order_risk_port::OrderRiskPort;

/// Mock 风控配置
#[derive(Debug, Clone)]
pub struct MockRiskConfig {
    /// 允许的交易对（空表示允许所有）
    pub allowed_symbols: HashSet<String>,
    /// 最小数量
    pub min_qty: Decimal,
    /// 最大数量
    pub max_qty: Decimal,
    /// 最大持仓
    pub max_position: Decimal,
    /// 是否启用交易
    pub trading_enabled: bool,
}

impl Default for MockRiskConfig {
    fn default() -> Self {
        Self {
            allowed_symbols: HashSet::new(),
            min_qty: Decimal::ZERO,
            max_qty: Decimal::new(100, 0),
            max_position: Decimal::new(10, 0),
            trading_enabled: true,
        }
    }
}

/// Mock 风控适配器
pub struct MockRiskAdapter {
    config: MockRiskConfig,
    /// 当前持仓（symbol -> quantity）
    positions: RwLock<HashMap<String, Decimal>>,
}

impl MockRiskAdapter {
    /// 创建 Mock 风控适配器
    pub fn new(config: MockRiskConfig) -> Self {
        Self {
            config,
            positions: RwLock::new(HashMap::new()),
        }
    }
}

#[async_trait]
impl OrderRiskPort for MockRiskAdapter {
    async fn check(&self, intent: &OrderIntent) -> Result<()> {
        // 规则 1: 交易是否启用
        if !self.config.trading_enabled {
            anyhow::bail!("TRADING_DISABLED: 交易已禁用");
        }

        // 规则 2: Symbol 白名单
        if !self.config.allowed_symbols.is_empty()
            && !self.config.allowed_symbols.contains(&intent.symbol)
        {
            anyhow::bail!(
                "SYMBOL_NOT_ALLOWED: 交易对 {} 不在白名单中",
                intent.symbol
            );
        }

        // 规则 3: Symbol 不能为空
        if intent.symbol.is_empty() {
            anyhow::bail!("INVALID_SYMBOL: 交易对不能为空");
        }

        // 规则 4: 数量范围检查
        if intent.quantity <= Decimal::ZERO {
            anyhow::bail!("INVALID_QUANTITY: 数量必须大于 0");
        }
        if intent.quantity < self.config.min_qty {
            anyhow::bail!(
                "QUANTITY_TOO_SMALL: 数量 {} 小于最小值 {}",
                intent.quantity,
                self.config.min_qty
            );
        }
        if intent.quantity > self.config.max_qty {
            anyhow::bail!(
                "QUANTITY_TOO_LARGE: 数量 {} 大于最大值 {}",
                intent.quantity,
                self.config.max_qty
            );
        }

        // 规则 5: 仓位检查
        let positions = self.positions.read().map_err(|e| {
            anyhow::anyhow!("INTERNAL_ERROR: 读取仓位失败: {}", e)
        })?;
        let current_position = positions.get(&intent.symbol).copied().unwrap_or(Decimal::ZERO);
        let new_position = current_position + intent.quantity;
        
        if new_position.abs() > self.config.max_position {
            anyhow::bail!(
                "POSITION_EXCEEDS_LIMIT: 新仓位 {} 超过最大限制 {}",
                new_position,
                self.config.max_position
            );
        }

        Ok(())
    }

    async fn update_position(&self, symbol: &str, delta: Decimal) {
        if let Ok(mut positions) = self.positions.write() {
            let current = positions.get(symbol).copied().unwrap_or(Decimal::ZERO);
            positions.insert(symbol.to_string(), current + delta);
        }
    }

    async fn record_order_time(&self, _symbol: &str) {
        // Mock 实现：不做任何事
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::domain::model::order_intent::OrderSide;
    use uuid::Uuid;

    fn dec(s: &str) -> Decimal {
        s.parse().unwrap_or_default()
    }

    #[tokio::test]
    async fn test_mock_risk_pass() {
        let adapter = MockRiskAdapter::new(MockRiskConfig::default());
        let intent = OrderIntent::new(
            Uuid::new_v4(),
            "BTCUSDT".to_string(),
            OrderSide::Buy,
            dec("0.1"),
            Some(dec("50000")),
            0.9,
        );
        
        let result = adapter.check(&intent).await;
        assert!(result.is_ok());
    }

    #[tokio::test]
    async fn test_mock_risk_reject_empty_symbol() {
        let adapter = MockRiskAdapter::new(MockRiskConfig::default());
        let intent = OrderIntent::new(
            Uuid::new_v4(),
            "".to_string(),
            OrderSide::Buy,
            dec("0.1"),
            Some(dec("50000")),
            0.9,
        );
        
        let result = adapter.check(&intent).await;
        assert!(result.is_err());
        assert!(result.unwrap_err().to_string().contains("INVALID_SYMBOL"));
    }

    #[tokio::test]
    async fn test_mock_risk_reject_invalid_quantity() {
        let adapter = MockRiskAdapter::new(MockRiskConfig::default());
        let intent = OrderIntent::new(
            Uuid::new_v4(),
            "BTCUSDT".to_string(),
            OrderSide::Buy,
            dec("0"),
            Some(dec("50000")),
            0.9,
        );
        
        let result = adapter.check(&intent).await;
        assert!(result.is_err());
        assert!(result.unwrap_err().to_string().contains("INVALID_QUANTITY"));
    }

    #[tokio::test]
    async fn test_mock_risk_reject_position_limit() {
        let config = MockRiskConfig {
            max_position: dec("1"),
            ..Default::default()
        };
        let adapter = MockRiskAdapter::new(config);
        
        // 第一笔通过
        let intent1 = OrderIntent::new(
            Uuid::new_v4(),
            "BTCUSDT".to_string(),
            OrderSide::Buy,
            dec("0.5"),
            Some(dec("50000")),
            0.9,
        );
        assert!(adapter.check(&intent1).await.is_ok());
        adapter.update_position("BTCUSDT", dec("0.5")).await;
        
        // 第二笔超限
        let intent2 = OrderIntent::new(
            Uuid::new_v4(),
            "BTCUSDT".to_string(),
            OrderSide::Buy,
            dec("0.6"),
            Some(dec("50000")),
            0.9,
        );
        let result = adapter.check(&intent2).await;
        assert!(result.is_err());
        assert!(result.unwrap_err().to_string().contains("POSITION_EXCEEDS_LIMIT"));
    }
}
