//! # 风控基础设施适配器
//!
//! 路径: services/trading-engine/src/infrastructure/risk/mod.rs
//!
//! ## 职责
//! 实现 OrderRiskPort 的适配器。
//!
//! ## 架构说明
//! 风控逻辑已完全迁移到 risk-management 服务 (8085)
//! - RemoteRiskAdapter: 生产环境使用，调用 risk-management 服务
//! - MockRiskAdapter: 测试环境使用，本地 Mock 实现

pub mod mock_risk_adapter;
pub mod remote_risk_adapter;

pub use mock_risk_adapter::{MockRiskAdapter, MockRiskConfig};
pub use remote_risk_adapter::RemoteRiskAdapter;
