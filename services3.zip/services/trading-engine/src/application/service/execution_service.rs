//! # 交易主链路调度服务 (Execution Service)
//!
//! 这是交易系统的核心调度层。
//! 所有交易流程必须经过此服务，不允许绕过。
//!
//! ## 职责
//! 1. 接收 MarketEvent
//! 2. 调用 StrategyPort → 获取 OrderIntent
//! 3. 调用 OrderRiskPort → 校验 OrderIntent
//! 4. 调用 OrderExecutionPort → 执行 OrderIntent
//! 5. 下单成功后 → 更新风控状态 + 落库 + 审计记录
//!
//! ## 禁止
//! - 禁止包含任何策略逻辑
//! - 禁止包含任何风控规则
//! - 禁止包含任何执行实现
//! - 禁止直接调用交易所 API

use std::sync::Arc;

use chrono::Utc;
use shared::event::market_event::MarketEvent;
use tracing::{info, warn, error};
use uuid::Uuid;

use crate::domain::model::order::{Order, OrderSide, OrderStatus, OrderType};
use crate::domain::model::audit_event::{ExecutionResultEvent, RiskRejectedEvent};
use crate::domain::port::order_execution_port::OrderExecutionPort;
use crate::domain::port::order_repository_port::OrderRepositoryPort;
use crate::domain::port::order_risk_port::OrderRiskPort;
use crate::domain::port::strategy_port::StrategyPort;
use crate::domain::port::trade_audit_port::TradeAuditPort;

/// 交易主链路调度服务
///
/// 统一调度 Strategy → Risk → Execution 的唯一入口。
/// "谁掌权谁负责" - 中枢大脑负责所有后处理工作。
pub struct ExecutionService {
    strategy: Arc<dyn StrategyPort>,
    risk: Arc<dyn OrderRiskPort>,
    execution: Arc<dyn OrderExecutionPort>,
    /// 订单仓储（可选，用于落库）
    order_repo: Option<Arc<dyn OrderRepositoryPort>>,
    /// 交易审计（可选，用于记录风控决策和执行结果）
    audit: Option<Arc<dyn TradeAuditPort>>,
}

impl ExecutionService {
    /// 创建交易主链路调度服务
    ///
    /// # 参数
    /// - `strategy`: 策略端口
    /// - `risk`: 风控端口
    /// - `execution`: 执行端口
    pub fn new(
        strategy: Arc<dyn StrategyPort>,
        risk: Arc<dyn OrderRiskPort>,
        execution: Arc<dyn OrderExecutionPort>,
    ) -> Self {
        Self {
            strategy,
            risk,
            execution,
            order_repo: None,
            audit: None,
        }
    }

    /// 创建带订单仓储的交易主链路调度服务
    ///
    /// # 参数
    /// - `strategy`: 策略端口
    /// - `risk`: 风控端口
    /// - `execution`: 执行端口
    /// - `order_repo`: 订单仓储端口
    pub fn with_repository(
        strategy: Arc<dyn StrategyPort>,
        risk: Arc<dyn OrderRiskPort>,
        execution: Arc<dyn OrderExecutionPort>,
        order_repo: Arc<dyn OrderRepositoryPort>,
    ) -> Self {
        Self {
            strategy,
            risk,
            execution,
            order_repo: Some(order_repo),
            audit: None,
        }
    }

    /// 创建完整配置的交易主链路调度服务
    ///
    /// # 参数
    /// - `strategy`: 策略端口
    /// - `risk`: 风控端口
    /// - `execution`: 执行端口
    /// - `order_repo`: 订单仓储端口（可选）
    /// - `audit`: 交易审计端口（可选）
    pub fn with_full_config(
        strategy: Arc<dyn StrategyPort>,
        risk: Arc<dyn OrderRiskPort>,
        execution: Arc<dyn OrderExecutionPort>,
        order_repo: Option<Arc<dyn OrderRepositoryPort>>,
        audit: Option<Arc<dyn TradeAuditPort>>,
    ) -> Self {
        Self {
            strategy,
            risk,
            execution,
            order_repo,
            audit,
        }
    }

    /// 处理行情事件
    ///
    /// 这是交易主链路的唯一入口。
    /// 流程：MarketEvent → Strategy → Risk → Execution → 后处理（落库+更新风控）
    ///
    /// # 参数
    /// - `event`: 行情事件
    ///
    /// # 返回
    /// - `Ok(())`: 处理完成（不代表一定有交易）
    /// - `Err`: 处理失败
    pub async fn on_market_event(&self, event: &MarketEvent) -> anyhow::Result<()> {
        // Step 1: 调用策略，获取交易意图
        let intent = match self.strategy.evaluate(event).await {
            Ok(Some(intent)) => {
                info!(
                    symbol = %intent.symbol,
                    side = ?intent.side,
                    quantity = %intent.quantity,
                    "Strategy generated order intent"
                );
                intent
            }
            Ok(None) => {
                // 策略无交易意图，正常情况
                return Ok(());
            }
            Err(err) => {
                warn!(error = %err, "Strategy evaluation failed");
                return Err(err);
            }
        };

        // Step 2: 调用风控，校验交易意图
        // 明确区分：Strategy None vs Risk Rejected
        if let Err(risk_err) = self.risk.check(&intent).await {
            // 风控拒绝 - 明确记录拒绝原因，不触发 Execution
            let reject_reason = risk_err.to_string();
            let reject_code = Self::extract_reject_code(&reject_reason);
            
            info!(
                symbol = %intent.symbol,
                side = ?intent.side,
                quantity = %intent.quantity,
                reject_reason = %reject_reason,
                reject_code = %reject_code,
                outcome = "RISK_REJECTED",
                "Order intent rejected by risk check - execution skipped"
            );

            // 记录风控拒绝事件（审计）
            if let Some(ref audit) = self.audit {
                let reject_event = RiskRejectedEvent::new(
                    intent.strategy_id,
                    intent.symbol.clone(),
                    intent.side,
                    intent.quantity,
                    intent.price,
                    reject_reason,
                    reject_code,
                );
                if let Err(e) = audit.record_risk_rejected(&reject_event).await {
                    error!(error = %e, "Failed to record risk rejected event");
                }
            }

            // 风控拒绝不是系统错误，只是不执行，返回 Ok
            return Ok(());
        }

        info!(
            symbol = %intent.symbol,
            side = ?intent.side,
            outcome = "RISK_PASSED",
            "Order intent passed risk check, proceeding to execution"
        );

        // Step 3: 调用执行，执行交易意图
        let result = match self.execution.execute(&intent).await {
            Ok(result) => result,
            Err(err) => {
                // 记录执行失败事件
                if let Some(ref audit) = self.audit {
                    let fail_event = ExecutionResultEvent::failure(
                        intent.strategy_id,
                        intent.symbol.clone(),
                        intent.side,
                        intent.quantity,
                        err.to_string(),
                    );
                    if let Err(e) = audit.record_execution_result(&fail_event).await {
                        error!(error = %e, "Failed to record execution failure event");
                    }
                }
                warn!(
                    symbol = %intent.symbol,
                    error = %err,
                    "Order execution error"
                );
                return Err(err);
            }
        };

        // Step 4: 后处理（中枢大脑负责）
        if result.success {
            info!(
                symbol = %result.symbol,
                order_id = %result.order_id,
                "Order executed successfully, starting post-processing"
            );

            // 4.1 更新风控状态 - 持仓
            let position_delta = match intent.side {
                crate::domain::model::order_intent::OrderSide::Buy => intent.quantity,
                crate::domain::model::order_intent::OrderSide::Sell => -intent.quantity,
            };
            self.risk.update_position(&intent.symbol, position_delta).await;

            // 4.2 更新风控状态 - 下单时间
            self.risk.record_order_time(&intent.symbol).await;

            // 4.3 记录执行成功事件（审计）
            if let Some(ref audit) = self.audit {
                let success_event = ExecutionResultEvent::success(
                    intent.strategy_id,
                    intent.symbol.clone(),
                    intent.side,
                    intent.quantity,
                    result.order_id.clone(),
                );
                if let Err(e) = audit.record_execution_result(&success_event).await {
                    error!(error = %e, "Failed to record execution success event");
                }
            }

            // 4.4 落库（如果配置了仓储）
            if let Some(ref repo) = self.order_repo {
                // 根据是否有价格判断订单类型
                let order_type = if intent.price.is_some() {
                    OrderType::Limit
                } else {
                    OrderType::Market
                };

                let order = Order {
                    id: Uuid::new_v4(),
                    user_id: intent.strategy_id, // 暂用 strategy_id 作为 user_id
                    strategy_id: Some(intent.strategy_id),
                    symbol: intent.symbol.clone(),
                    side: match intent.side {
                        crate::domain::model::order_intent::OrderSide::Buy => OrderSide::Buy,
                        crate::domain::model::order_intent::OrderSide::Sell => OrderSide::Sell,
                    },
                    order_type,
                    quantity: intent.quantity,
                    price: intent.price,
                    status: OrderStatus::Filled, // 成功执行的订单
                    exchange_order_id: Some(result.order_id.clone()),
                    filled_quantity: intent.quantity,
                    average_price: intent.price,
                    created_at: Utc::now(),
                    updated_at: Utc::now(),
                };

                if let Err(e) = repo.save_order(&order).await {
                    // 落库失败不影响主流程，只记录错误
                    error!(
                        order_id = %order.id,
                        error = %e,
                        "Failed to save order to database"
                    );
                } else {
                    info!(
                        order_id = %order.id,
                        exchange_order_id = %result.order_id,
                        "Order saved to database"
                    );
                }
            }
        } else {
            // 记录执行失败事件
            if let Some(ref audit) = self.audit {
                let fail_event = ExecutionResultEvent::failure(
                    intent.strategy_id,
                    intent.symbol.clone(),
                    intent.side,
                    intent.quantity,
                    result.error.clone().unwrap_or_else(|| "Unknown error".to_string()),
                );
                if let Err(e) = audit.record_execution_result(&fail_event).await {
                    error!(error = %e, "Failed to record execution failure event");
                }
            }
            warn!(
                symbol = %result.symbol,
                error = ?result.error,
                "Order execution failed"
            );
        }

        Ok(())
    }

    /// 从拒绝原因中提取拒绝代码
    fn extract_reject_code(reason: &str) -> String {
        // 简单实现：取第一个冒号前的部分作为代码
        if let Some(pos) = reason.find(':') {
            reason[..pos].trim().to_uppercase().replace(' ', "_")
        } else {
            reason.trim().to_uppercase().replace(' ', "_")
        }
    }
}
