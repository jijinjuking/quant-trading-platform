//! # 领域模型模块
//!
//! 本文件导出所有领域模型定义。
//!
//! ## 子模块
//! - `notification`: 通知领域模型

/// 通知模型模块
pub mod notification;
