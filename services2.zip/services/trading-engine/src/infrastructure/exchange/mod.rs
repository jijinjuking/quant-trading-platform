//! # 交易所连接器 (Exchange Connectors)
//!
//! 提供与各交易所 API 交互的具体实现。
//!
//! ## 说明
//! 当前交易所连接功能已迁移到 infrastructure/execution/ 目录。
//! 此目录保留用于未来扩展（如行情查询、账户查询等）。
