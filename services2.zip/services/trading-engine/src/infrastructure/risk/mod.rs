//! # 风控基础设施适配器
//!
//! 路径: services/trading-engine/src/infrastructure/risk/mod.rs
//!
//! ## 职责
//! 实现 OrderRiskPort 的适配器。

pub mod order_risk_adapter;

pub use order_risk_adapter::{OrderRiskAdapter, RiskAdapterConfig};
