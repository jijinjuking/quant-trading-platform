//! # 风控端口工厂
//!
//! 路径: services/trading-engine/src/bootstrap/risk.rs
//!
//! ## 职责
//! 创建 OrderRiskPort 和 RiskStatePort 实现
//!
//! ## 风控架构
//! - OrderRiskPort: 调用远程 risk-management 服务 (8085)
//! - RiskStatePort: 本地维护账户状态（余额、持仓、未完成订单）

use std::sync::Arc;

use crate::domain::port::order_risk_port::OrderRiskPort;
use crate::domain::port::risk_state_port::RiskStatePort;
use crate::infrastructure::risk::RemoteRiskAdapter;
use crate::infrastructure::exchange::BinanceQueryAdapter;
use crate::application::service::risk_state_initializer::create_initialized_risk_state;

/// 创建风控端口（远程模式）
///
/// # 参数
/// - `url`: risk-management 服务 URL
///
/// # 返回
/// - `Arc<dyn OrderRiskPort>`: 风控端口实例
pub fn create_risk_port(url: Option<String>) -> Arc<dyn OrderRiskPort> {
    let url = url.unwrap_or_else(|| "http://localhost:8085".to_string());
    tracing::info!(url = %url, "使用远程风控服务 (risk-management)");
    Arc::new(RemoteRiskAdapter::new(url))
}

/// 创建并初始化 RiskStatePort
///
/// 如果配置了币安 API，则从交易所同步初始状态。
///
/// # 参数
/// - `binance_api_key`: 币安 API Key
/// - `binance_secret_key`: 币安 Secret Key
/// - `binance_base_url`: 币安 API Base URL
///
/// # 返回
/// - `Arc<dyn RiskStatePort>`: 风控状态端口实例
pub async fn create_risk_state(
    binance_api_key: Option<String>,
    binance_secret_key: Option<String>,
    binance_base_url: String,
) -> Arc<dyn RiskStatePort> {
    match (binance_api_key, binance_secret_key) {
        (Some(api_key), Some(secret_key)) => {
            let exchange_query = BinanceQueryAdapter::new(
                api_key,
                secret_key,
                binance_base_url,
            );
            let risk_state = create_initialized_risk_state(Some(&exchange_query)).await;
            tracing::info!("RiskStatePort 已初始化（从交易所同步）");
            risk_state
        }
        _ => {
            let risk_state = create_initialized_risk_state(None).await;
            tracing::info!("RiskStatePort 已初始化（空状态）");
            risk_state
        }
    }
}
