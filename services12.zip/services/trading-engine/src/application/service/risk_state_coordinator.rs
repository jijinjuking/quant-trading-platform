//! # 风控状态协调器 (Risk State Coordinator)
//!
//! 路径: services/trading-engine/src/application/service/risk_state_coordinator.rs
//!
//! ## 职责
//! 统一管理 RiskState 的生命周期，包括：
//! - 启动时初始化
//! - WebSocket 重连后重建
//! - 提供唯一的状态重建入口
//!
//! ## 架构约束
//! - 只有 RiskStateCoordinator 可以执行全量重建
//! - OrderLifecycleService 只能删除 open_orders
//! - 其他组件不得直接修改 RiskState
//!
//! ## 写权限规则
//! | 模块 | 权限 |
//! |------|------|
//! | RiskStateCoordinator | ✅ 全量重建 |
//! | OrderLifecycleService | ✅ 删除 open_orders |
//! | RiskAdapter | ❌ 直接写 |
//! | WS Stream | ❌ 直接写 |
//! | Strategy/Execution | ❌ 写 |

use std::sync::Arc;

use anyhow::Result;
use tokio::sync::RwLock;
use tracing::{info, warn, error};

use crate::domain::port::exchange_query_port::ExchangeQueryPort;
use crate::domain::port::risk_state_port::RiskStatePort;
use crate::application::service::risk_state_initializer::RiskStateInitializer;

/// 重建原因
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RebuildReason {
    /// 服务启动
    Startup,
    /// WebSocket 重连
    WsReconnect,
    /// 手动触发
    Manual,
}

impl std::fmt::Display for RebuildReason {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            RebuildReason::Startup => write!(f, "startup"),
            RebuildReason::WsReconnect => write!(f, "ws_reconnect"),
            RebuildReason::Manual => write!(f, "manual"),
        }
    }
}

/// 风控状态协调器
///
/// 统一管理 RiskState 的生命周期。
/// 所有状态重建操作必须通过此协调器进行。
pub struct RiskStateCoordinator {
    /// 风控状态端口（共享）
    risk_state: Arc<dyn RiskStatePort>,
    /// 交易所查询端口（可选，用于同步状态）
    exchange_query: Option<Arc<dyn ExchangeQueryPort>>,
    /// 重建锁（防止并发重建）
    rebuild_lock: RwLock<()>,
    /// 是否已初始化
    initialized: RwLock<bool>,
}

impl RiskStateCoordinator {
    /// 创建协调器
    ///
    /// # 参数
    /// - `risk_state`: 风控状态端口（共享实例）
    /// - `exchange_query`: 交易所查询端口（可选）
    pub fn new(
        risk_state: Arc<dyn RiskStatePort>,
        exchange_query: Option<Arc<dyn ExchangeQueryPort>>,
    ) -> Self {
        Self {
            risk_state,
            exchange_query,
            rebuild_lock: RwLock::new(()),
            initialized: RwLock::new(false),
        }
    }

    /// 获取 RiskState 端口（只读访问）
    pub fn risk_state(&self) -> Arc<dyn RiskStatePort> {
        Arc::clone(&self.risk_state)
    }

    /// 执行状态重建（唯一入口）
    ///
    /// 从交易所同步最新状态到 RiskState。
    /// 此方法是线程安全的，会自动防止并发重建。
    ///
    /// # 参数
    /// - `reason`: 重建原因
    ///
    /// # 返回
    /// - `Ok(())`: 重建成功
    /// - `Err`: 重建失败（不影响服务运行）
    pub async fn rebuild(&self, reason: RebuildReason) -> Result<()> {
        // 获取重建锁，防止并发
        let _guard = self.rebuild_lock.write().await;

        info!(reason = %reason, "开始重建风控状态...");

        // 检查是否有交易所查询端口
        let Some(ref exchange) = self.exchange_query else {
            warn!("未配置交易所查询端口，跳过状态重建");
            return Ok(());
        };

        // 调用初始化器执行同步
        match RiskStateInitializer::initialize(exchange.as_ref(), self.risk_state.as_ref()).await {
            Ok(()) => {
                info!(reason = %reason, "风控状态重建完成");
                
                // 标记已初始化
                let mut init = self.initialized.write().await;
                *init = true;
                
                Ok(())
            }
            Err(e) => {
                error!(reason = %reason, error = %e, "风控状态重建失败");
                Err(e)
            }
        }
    }

    /// 通知 WebSocket 重连
    ///
    /// 由 BinanceFillStream 在重连成功后调用。
    /// 内部会触发状态重建。
    pub async fn notify_reconnect(&self) {
        info!("收到 WebSocket 重连通知，触发状态重建...");
        
        if let Err(e) = self.rebuild(RebuildReason::WsReconnect).await {
            error!(error = %e, "WebSocket 重连后状态重建失败");
        }
    }

    /// 检查是否已初始化
    pub async fn is_initialized(&self) -> bool {
        *self.initialized.read().await
    }
}

// ============================================================================
// 测试模块
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;
    use crate::infrastructure::risk::InMemoryRiskStateAdapter;

    #[tokio::test]
    async fn test_coordinator_without_exchange() {
        let risk_state = Arc::new(InMemoryRiskStateAdapter::new());
        let coordinator = RiskStateCoordinator::new(risk_state.clone(), None);

        // 没有交易所查询端口时，重建应该成功但跳过
        let result = coordinator.rebuild(RebuildReason::Startup).await;
        assert!(result.is_ok());
    }

    #[tokio::test]
    async fn test_coordinator_risk_state_shared() {
        let risk_state = Arc::new(InMemoryRiskStateAdapter::new());
        let coordinator = RiskStateCoordinator::new(risk_state.clone(), None);

        // 验证返回的是同一个实例
        let state1 = coordinator.risk_state();
        let state2 = coordinator.risk_state();
        
        // 通过 Arc::ptr_eq 验证是同一个实例
        assert!(Arc::ptr_eq(&state1, &state2));
    }

    #[test]
    fn test_rebuild_reason_display() {
        assert_eq!(RebuildReason::Startup.to_string(), "startup");
        assert_eq!(RebuildReason::WsReconnect.to_string(), "ws_reconnect");
        assert_eq!(RebuildReason::Manual.to_string(), "manual");
    }
}
