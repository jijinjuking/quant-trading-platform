//! # 应用层 (Application Layer)
//!
//! market-data 服务的应用层，负责用例编排。

pub mod market_data_service;

pub use market_data_service::MarketDataService;
