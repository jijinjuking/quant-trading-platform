//! # Execution 主链路 Smoke Test
//!
//! 验证 Port + Adapter + Service 能跑通。
//!
//! ## 测试范围
//! - ExecutionPort trait 可被实现
//! - NoopExecution 能正常执行
//! - ExecutionService 能调度完整链路

use std::collections::HashSet;
use std::sync::Arc;

// 导入 trading-engine 模块
use trading_engine::domain::port::execution_port::{ExecutionCommand, ExecutionPort};
use trading_engine::domain::port::strategy_port::StrategyPort;
use trading_engine::domain::port::order_risk_port::OrderRiskPort;
use trading_engine::domain::port::order_execution_port::OrderExecutionPort;
use trading_engine::domain::model::order_intent::{OrderIntent, OrderSide};
use trading_engine::infrastructure::execution::{NoopExecution, OrderExecutor};
use trading_engine::infrastructure::strategy::NoopStrategy;
use trading_engine::infrastructure::risk::{OrderRiskAdapter, RiskConfig};
use trading_engine::application::service::execution_service::ExecutionService;

use rust_decimal::Decimal;
use std::str::FromStr;
use shared::event::market_event::{MarketEvent, MarketEventType, MarketEventData, TradeData};
use chrono::Utc;
use uuid::Uuid;

/// 辅助函数：创建 Decimal
fn dec(s: &str) -> Decimal {
    Decimal::from_str(s).unwrap_or_default()
}

/// Test 1: ExecutionPort + NoopExecution 基础验证
#[tokio::test]
async fn test_noop_execution_port() {
    let executor = NoopExecution::new();
    
    let command = ExecutionCommand {
        symbol: "BTCUSDT".to_string(),
        side: "buy".to_string(),
        quantity: "0.001".to_string(),
    };
    
    let result = executor.execute(&command).await;
    
    // NoopExecution 应该始终成功
    assert!(result.is_ok(), "NoopExecution should always succeed");
}

/// Test 2: OrderExecutor 适配器验证
#[tokio::test]
async fn test_order_executor_adapter() {
    let inner: Arc<dyn ExecutionPort> = Arc::new(NoopExecution::new());
    let executor = OrderExecutor::new(inner);
    
    let intent = OrderIntent::new(
        Uuid::new_v4(),
        "ETHUSDT".to_string(),
        OrderSide::Sell,
        dec("0.1"),
        Some(dec("2000.0")),
        0.8,
    );
    
    let result = executor.execute(&intent).await;
    
    assert!(result.is_ok(), "OrderExecutor should succeed with NoopExecution");
    let exec_result = result.unwrap();
    assert!(exec_result.success, "Execution result should be success");
    assert_eq!(exec_result.symbol, "ETHUSDT");
}

/// Test 3: ExecutionService 完整链路验证
#[tokio::test]
async fn test_execution_service_full_chain() {
    // 1. 创建所有依赖
    let strategy: Arc<dyn StrategyPort> = Arc::new(NoopStrategy::new());
    
    // 使用默认配置（允许所有交易对）
    let risk: Arc<dyn OrderRiskPort> = Arc::new(OrderRiskAdapter::new(RiskConfig::default()));
    
    let inner_exec: Arc<dyn ExecutionPort> = Arc::new(NoopExecution::new());
    let execution: Arc<dyn OrderExecutionPort> = Arc::new(OrderExecutor::new(inner_exec));
    
    // 2. 创建 ExecutionService
    let service = ExecutionService::new(strategy, risk, execution);
    
    // 3. 构造 MarketEvent
    let event = MarketEvent {
        event_type: MarketEventType::Trade,
        exchange: "binance".to_string(),
        symbol: "BTCUSDT".to_string(),
        timestamp: Utc::now(),
        data: MarketEventData::Trade(TradeData {
            trade_id: "12345".to_string(),
            price: dec("50000.0"),
            quantity: dec("0.001"),
            is_buyer_maker: false,
        }),
    };
    
    // 4. 调用主链路
    let result = service.on_market_event(&event).await;
    
    // NoopStrategy 不产生意图，所以链路应该正常结束
    assert!(result.is_ok(), "ExecutionService should handle event without error");
}

/// Test 4: 风控拦截验证
#[tokio::test]
async fn test_risk_rejection() {
    // 创建一个只允许 BTCUSDT 的风控配置
    let mut allowed_symbols = HashSet::new();
    allowed_symbols.insert("BTCUSDT".to_string());
    
    let config = RiskConfig {
        allowed_symbols,
        min_qty: Decimal::ZERO,
        max_qty: Decimal::new(100, 0),
        max_notional: Decimal::new(100000, 0),
        max_position: Decimal::new(10, 0),
        cooldown_ms: 0, // 禁用冷却以便测试
    };
    
    let risk = OrderRiskAdapter::new(config);
    
    // 创建一个 ETHUSDT 的意图
    let intent = OrderIntent::new(
        Uuid::new_v4(),
        "ETHUSDT".to_string(), // 不在白名单
        OrderSide::Buy,
        dec("0.1"),
        Some(dec("2000.0")),
        0.9,
    );
    
    let result = risk.check(&intent).await;
    
    // 应该被拒绝
    assert!(result.is_err(), "Risk should reject non-whitelisted symbol");
}
