//! # 领域模型 (Domain Models)
//!
//! 定义交易引擎的核心领域模型。
//!
//! ## 设计原则
//! - 所有模型都是纯数据结构
//! - 不包含任何外部依赖（HTTP/DB/SDK）
//! - 可被其他层安全引用

/// 交易意图模型 - 策略产生的交易意图
pub mod order_intent;

/// 订单模型
pub mod order;

/// 成交记录模型
pub mod trade;

/// 风控上下文模型 - 风控检查所需的账户/仓位快照
pub mod risk_context;

/// 风控事件模型 - 风控决策和执行结果事件
pub mod risk_event;
