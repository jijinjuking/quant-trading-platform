//! # 风控规则 (Risk Rules)
//!
//! 路径: services/trading-engine/src/domain/logic/risk_rules.rs
//!
//! ## 职责
//! 定义风控规则的组合顺序和执行逻辑。
//! 所有规则按顺序执行，任一失败即短路返回。
//!
//! ## 规则执行顺序（v1 共 5 条）
//! 1. 熔断检查 - 连续 N 次拒绝后暂停交易
//! 2. 账户状态检查 - 账户是否允许交易
//! 3. 单笔最大名义价值 - 防止单笔过大
//! 4. 单 Symbol 最大仓位 - 防止单币种过度集中
//! 5. 重复订单检查 - 防止同方向重复下单
//!
//! ## 设计原则
//! - 纯函数，无副作用
//! - 规则顺序明确，短路执行
//! - 拒绝原因可枚举、可追踪

use std::fmt;

use rust_decimal::Decimal;

use crate::domain::model::order_intent::OrderIntent;
use crate::domain::model::risk_context::RiskContext;

/// 风控规则配置
#[derive(Debug, Clone)]
pub struct RiskRulesConfig {
    /// 单笔最大名义价值 (USDT)
    pub max_notional_per_order: Decimal,
    /// 单 Symbol 最大仓位 (数量)
    pub max_position_per_symbol: Decimal,
    /// 触发熔断的连续拒绝次数
    pub circuit_breaker_threshold: u32,
    /// 熔断持续时间（秒）
    pub circuit_breaker_duration_secs: i64,
    /// 是否允许同方向重复下单
    pub allow_duplicate_orders: bool,
}

impl Default for RiskRulesConfig {
    fn default() -> Self {
        Self {
            max_notional_per_order: Decimal::new(10000, 0),  // 1万 USDT
            max_position_per_symbol: Decimal::new(10, 0),    // 10 个
            circuit_breaker_threshold: 5,                     // 连续 5 次拒绝
            circuit_breaker_duration_secs: 300,               // 熔断 5 分钟
            allow_duplicate_orders: false,                    // 不允许重复下单
        }
    }
}

/// 风控拒绝原因（可枚举、可读、可追踪）
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum RiskRejectReason {
    /// 熔断中 - 连续拒绝触发
    CircuitBreakerActive {
        consecutive_rejects: u32,
        until: String,
    },
    /// 账户交易已禁用
    TradingDisabled,
    /// 单笔名义价值超限
    NotionalExceedsLimit {
        notional: Decimal,
        limit: Decimal,
    },
    /// 单 Symbol 仓位超限
    PositionExceedsLimit {
        symbol: String,
        current: Decimal,
        after: Decimal,
        limit: Decimal,
    },
    /// 存在同方向未完成订单
    DuplicateOrderExists {
        symbol: String,
        side: String,
        pending_count: usize,
    },
    /// Symbol 不在白名单
    SymbolNotAllowed {
        symbol: String,
    },
    /// 数量低于最小值
    QuantityBelowMinimum {
        quantity: Decimal,
        minimum: Decimal,
    },
    /// 数量超过最大值
    QuantityAboveMaximum {
        quantity: Decimal,
        maximum: Decimal,
    },
}

impl fmt::Display for RiskRejectReason {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            RiskRejectReason::CircuitBreakerActive { consecutive_rejects, until } => {
                write!(f, "CIRCUIT_BREAKER: {} consecutive rejects, blocked until {}", 
                    consecutive_rejects, until)
            }
            RiskRejectReason::TradingDisabled => {
                write!(f, "TRADING_DISABLED: account trading is disabled")
            }
            RiskRejectReason::NotionalExceedsLimit { notional, limit } => {
                write!(f, "NOTIONAL_EXCEEDS_LIMIT: {} > {}", notional, limit)
            }
            RiskRejectReason::PositionExceedsLimit { symbol, current, after, limit } => {
                write!(f, "POSITION_EXCEEDS_LIMIT: {} current={} after={} limit={}", 
                    symbol, current, after, limit)
            }
            RiskRejectReason::DuplicateOrderExists { symbol, side, pending_count } => {
                write!(f, "DUPLICATE_ORDER: {} has {} pending {} orders", 
                    symbol, pending_count, side)
            }
            RiskRejectReason::SymbolNotAllowed { symbol } => {
                write!(f, "SYMBOL_NOT_ALLOWED: {}", symbol)
            }
            RiskRejectReason::QuantityBelowMinimum { quantity, minimum } => {
                write!(f, "QUANTITY_BELOW_MINIMUM: {} < {}", quantity, minimum)
            }
            RiskRejectReason::QuantityAboveMaximum { quantity, maximum } => {
                write!(f, "QUANTITY_ABOVE_MAXIMUM: {} > {}", quantity, maximum)
            }
        }
    }
}

impl std::error::Error for RiskRejectReason {}

/// 风控规则检查器
///
/// 按顺序执行所有规则，任一失败即返回拒绝原因。
pub struct RiskRulesChecker {
    config: RiskRulesConfig,
}

impl RiskRulesChecker {
    /// 创建规则检查器
    pub fn new(config: RiskRulesConfig) -> Self {
        Self { config }
    }

    /// 执行所有风控规则检查
    ///
    /// 规则执行顺序：
    /// 1. 熔断检查
    /// 2. 账户状态检查
    /// 3. 单笔最大名义价值
    /// 4. 单 Symbol 最大仓位
    /// 5. 重复订单检查
    ///
    /// # 返回
    /// - `Ok(())`: 所有规则通过
    /// - `Err(RiskRejectReason)`: 某条规则拒绝
    pub fn check_all(
        &self,
        intent: &OrderIntent,
        context: &RiskContext,
    ) -> Result<(), RiskRejectReason> {
        // 规则 1: 熔断检查
        self.check_circuit_breaker(context)?;

        // 规则 2: 账户状态检查
        self.check_account_enabled(context)?;

        // 规则 3: 单笔最大名义价值
        self.check_max_notional(intent)?;

        // 规则 4: 单 Symbol 最大仓位
        self.check_max_position(intent, context)?;

        // 规则 5: 重复订单检查
        self.check_duplicate_order(intent, context)?;

        Ok(())
    }

    /// 规则 1: 熔断检查
    fn check_circuit_breaker(&self, context: &RiskContext) -> Result<(), RiskRejectReason> {
        if context.risk_stats.circuit_breaker_active {
            let until = context.risk_stats.circuit_breaker_until
                .map(|t| t.to_rfc3339())
                .unwrap_or_else(|| "unknown".to_string());
            return Err(RiskRejectReason::CircuitBreakerActive {
                consecutive_rejects: context.risk_stats.consecutive_rejects,
                until,
            });
        }
        Ok(())
    }

    /// 规则 2: 账户状态检查
    fn check_account_enabled(&self, context: &RiskContext) -> Result<(), RiskRejectReason> {
        if !context.account.trading_enabled {
            return Err(RiskRejectReason::TradingDisabled);
        }
        Ok(())
    }

    /// 规则 3: 单笔最大名义价值
    fn check_max_notional(&self, intent: &OrderIntent) -> Result<(), RiskRejectReason> {
        if let Some(price) = intent.price {
            let notional = intent.quantity * price;
            if notional > self.config.max_notional_per_order {
                return Err(RiskRejectReason::NotionalExceedsLimit {
                    notional,
                    limit: self.config.max_notional_per_order,
                });
            }
        }
        Ok(())
    }

    /// 规则 4: 单 Symbol 最大仓位
    fn check_max_position(
        &self,
        intent: &OrderIntent,
        context: &RiskContext,
    ) -> Result<(), RiskRejectReason> {
        let symbol = intent.symbol.to_uppercase();
        let current_position = context.get_position_qty(&symbol);
        let after_position = current_position + intent.quantity;

        if after_position > self.config.max_position_per_symbol {
            return Err(RiskRejectReason::PositionExceedsLimit {
                symbol,
                current: current_position,
                after: after_position,
                limit: self.config.max_position_per_symbol,
            });
        }
        Ok(())
    }

    /// 规则 5: 重复订单检查
    fn check_duplicate_order(
        &self,
        intent: &OrderIntent,
        context: &RiskContext,
    ) -> Result<(), RiskRejectReason> {
        if self.config.allow_duplicate_orders {
            return Ok(());
        }

        let symbol = intent.symbol.to_uppercase();
        if context.has_pending_order_same_side(&symbol, intent.side) {
            let pending_count = context.get_pending_orders(&symbol)
                .iter()
                .filter(|o| o.side == intent.side)
                .count();
            return Err(RiskRejectReason::DuplicateOrderExists {
                symbol,
                side: format!("{:?}", intent.side),
                pending_count,
            });
        }
        Ok(())
    }

    /// 获取配置（用于日志/调试）
    pub fn config(&self) -> &RiskRulesConfig {
        &self.config
    }
}
