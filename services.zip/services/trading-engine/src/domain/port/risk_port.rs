//! 下单前风控校验端口。

use std::sync::Arc;

use async_trait::async_trait;
use shared::event::signal_event::SignalEvent;

#[async_trait]
pub trait RiskPort: Send + Sync {
    async fn check(&self, signal: &SignalEvent) -> anyhow::Result<()>;
}

#[async_trait]
impl<T: RiskPort> RiskPort for Arc<T> {
    async fn check(&self, signal: &SignalEvent) -> anyhow::Result<()> {
        (**self).check(signal).await
    }
}
