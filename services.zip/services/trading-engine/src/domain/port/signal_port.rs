//! Signal event port for consuming trading signals.

use std::sync::Arc;

use async_trait::async_trait;
use shared::event::signal_event::SignalEvent;

#[async_trait]
pub trait SignalPort: Send + Sync {
    async fn next_signal(&self) -> anyhow::Result<SignalEvent>;
}

#[async_trait]
impl<T: SignalPort> SignalPort for Arc<T> {
    async fn next_signal(&self) -> anyhow::Result<SignalEvent> {
        (**self).next_signal().await
    }
}
