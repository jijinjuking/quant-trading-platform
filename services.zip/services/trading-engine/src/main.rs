//! # 交易引擎服务 - 入口文件
//!
//! ## 功能层级: 【入口层】
//! ## 服务端口: 8081
//! ## 职责: 消费行情 → 调用策略 → 风控检查 → 执行下单
//!
//! ## 交易主链路
//! ```text
//! MarketEvent → ExecutionFlowService → Strategy → Risk → Execution
//! ```

// ============================================================
// 模块声明 - 引入各层模块
// ============================================================
mod state;          // 应用状态模块
mod interface;      // 接口层 - HTTP/gRPC入口
mod application;    // 应用层 - 用例编排
mod domain;         // 领域层 - 核心业务逻辑
mod infrastructure; // 基础设施层 - 外部依赖实现
mod bootstrap;      // 依赖注入模块

// ============================================================
// 外部依赖导入
// ============================================================
use anyhow::Result;
use std::net::SocketAddr;
use tracing::{error, info};

/// # 主函数 - 服务启动入口
///
/// ## 执行流程:
/// 1. 初始化日志系统
/// 2. 创建应用状态
/// 3. 启动交易主链路消费者
/// 4. 创建 HTTP 路由
/// 5. 绑定端口并启动服务
#[tokio::main]
async fn main() -> Result<()> {
    // 加载 .env 文件
    dotenvy::dotenv().ok();

    // 初始化日志订阅器
    tracing_subscriber::fmt::init();

    println!("[trading-engine] Starting...");
    info!("Trading Engine starting...");

    // 创建应用状态（包含配置）
    let state = state::AppState::new().await?;
    info!(
        kafka_brokers = %state.config.kafka_brokers,
        kafka_market_topic = %state.config.kafka_market_topic,
        "Config loaded"
    );
    let config = state.config.as_ref().clone();

    // 启动交易主链路：MarketEvent → ExecutionFlowService → Strategy → Risk → Execution
    let market_consumer = bootstrap::create_market_event_consumer(
        config.kafka_brokers.clone(),
        config.kafka_market_topic.clone(),
        config.kafka_consumer_group.clone(),
        config.strategy_mode.clone(),
        config.strategy_engine_url.clone(),
        config.execution_mode.clone(),
        config.binance_api_key.clone(),
        config.binance_secret_key.clone(),
        config.binance_base_url.clone(),
        config.risk_min_qty,
        config.risk_max_qty,
        config.risk_max_notional,
        config.risk_allow_symbols.clone(),
        config.storage_enabled,
    ).await?;

    tokio::spawn(async move {
        if let Err(err) = market_consumer.run().await {
            error!(error = %err, "market event consumer stopped");
        }
    });

    // 创建 HTTP 路由
    let app = interface::http::routes::create_router(state);

    // 从环境变量读取端口，默认 8081
    let port: u16 = std::env::var("TRADING_ENGINE_PORT")
        .ok()
        .and_then(|p| p.parse().ok())
        .unwrap_or(8081);

    let addr = SocketAddr::from(([0, 0, 0, 0], port));
    info!("Trading Engine listening on {}", addr);

    let listener = tokio::net::TcpListener::bind(addr).await?;
    axum::serve(listener, app).await?;

    Ok(())
}
