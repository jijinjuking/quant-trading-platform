//! 信号消费并触发执行的应用服务。

use std::sync::Arc;
use std::time::Duration;

use tracing::{error, info, warn};

use crate::domain::port::execution_port::{ExecutionCommand, ExecutionPort};
use crate::domain::port::risk_port::RiskPort;
use crate::domain::port::signal_port::SignalPort;
use shared::event::signal_event::SignalType;

pub struct SignalConsumerService<S, R>
where
    S: SignalPort,
    R: RiskPort,
{
    source: S,
    execution: Arc<dyn ExecutionPort>,
    risk: R,
}

impl<S, R> SignalConsumerService<S, R>
where
    S: SignalPort,
    R: RiskPort,
{
    pub fn new(source: S, execution: Arc<dyn ExecutionPort>, risk: R) -> Self {
        Self { source, execution, risk }
    }

    pub async fn run(&self) -> anyhow::Result<()> {
        println!("[SignalConsumerService] Started, waiting for signals...");
        info!("SignalConsumerService started");

        loop {
            match self.source.next_signal().await {
                Ok(signal) => {
                    let symbol = signal.symbol.clone();
                    println!(
                        "[SignalConsumerService] Received signal: symbol={}, type={:?}",
                        symbol, signal.signal_type
                    );

                    if let Err(err) = self.risk.check(&signal).await {
                        println!(
                            "[SignalConsumerService] BLOCKED by risk: symbol={}, error={}",
                            symbol, err
                        );
                        warn!(
                            symbol = %symbol,
                            error = %err,
                            "signal blocked by risk check"
                        );
                        continue;
                    }

                    let side = match signal.signal_type {
                        SignalType::Buy => "buy",
                        SignalType::Sell => "sell",
                        SignalType::Hold => {
                            println!("[SignalConsumerService] SKIP Hold signal: symbol={}", symbol);
                            continue;
                        }
                    };

                    println!(
                        "[SignalConsumerService] ✅ PASSED risk check: symbol={}, side={}, qty={}",
                        symbol, side, signal.quantity
                    );

                    let command = ExecutionCommand {
                        symbol: signal.symbol,
                        side: side.to_string(),
                        quantity: signal.quantity.to_string(),
                    };

                    if let Err(err) = self.execution.execute(&command).await {
                        warn!(
                            symbol = %command.symbol,
                            error = %err,
                            "execution failed"
                        );
                    }
                }
                Err(err) => {
                    error!(error = %err, "signal source error");
                    tokio::time::sleep(Duration::from_secs(1)).await;
                }
            }
        }
    }
}
