//! # 执行端口服务 (Execution Port Service) - v1 占位骨架
//!
//! 应用层服务，负责转发执行请求。
//!
//! ## 版本说明
//! v1 仅作为结构性通道，不做任何业务判断。
//!
//! ## 职责
//! - 接收执行请求
//! - 转发给 ExecutionPort
//!
//! ## 依赖规则
//! - ✅ 只依赖 `domain::port` 中的 trait
//! - ❌ 不直接依赖 infrastructure
//! - ❌ 不在 service 内 new adapter
//! - ❌ 不做业务判断
//! - ❌ 不保存状态
//!
//! ## 与 ExecutionService 的区别
//! - ExecutionService: 依赖 ExchangePort + OrderRepositoryPort（完整执行流程）
//! - ExecutionPortService: 仅依赖 ExecutionPort（v1 最小骨架）

use crate::domain::port::execution_port::{ExecutionPort, ExecutionCommand};
use tracing::debug;

/// 执行端口服务 - v1 占位骨架
///
/// 应用层执行服务，仅负责转发。
/// 构造函数由 bootstrap 注入。
pub struct ExecutionPortService<E>
where
    E: ExecutionPort,
{
    execution: E,
}

impl<E> ExecutionPortService<E>
where
    E: ExecutionPort,
{
    /// 创建服务实例（由 bootstrap 调用）
    pub fn new(execution: E) -> Self {
        Self { execution }
    }

    /// 执行指令（v1 仅转发）
    ///
    /// # 参数
    /// - `command`: 执行指令
    ///
    /// # 返回
    /// - `Ok(())`: 执行成功
    /// - `Err`: 执行失败
    pub async fn execute(&self, command: &ExecutionCommand) -> anyhow::Result<()> {
        debug!(
            symbol = %command.symbol,
            side = %command.side,
            "ExecutionPortService forwarding to ExecutionPort"
        );
        self.execution.execute(command).await
    }
}
