//! 风控适配器 - Infrastructure 层只调用 domain 逻辑

use async_trait::async_trait;
use shared::event::signal_event::SignalEvent;

use crate::domain::logic::risk_rules::{check_risk_limits, RiskLimits};
use crate::domain::port::risk_port::RiskPort;

pub struct LimitsRisk {
    limits: RiskLimits,
}

impl LimitsRisk {
    pub fn new(
        min_qty: Option<rust_decimal::Decimal>,
        max_qty: Option<rust_decimal::Decimal>,
        max_notional: Option<rust_decimal::Decimal>,
        allow_symbols: Option<Vec<String>>,
    ) -> Self {
        Self {
            limits: RiskLimits::new(min_qty, max_qty, max_notional, allow_symbols),
        }
    }
}

#[async_trait]
impl RiskPort for LimitsRisk {
    async fn check(&self, signal: &SignalEvent) -> anyhow::Result<()> {
        check_risk_limits(signal, &self.limits)
    }
}
