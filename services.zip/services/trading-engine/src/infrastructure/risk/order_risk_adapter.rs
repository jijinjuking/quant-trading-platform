//! # 订单风控适配器 (Order Risk Adapter)
//!
//! 路径: services/trading-engine/src/infrastructure/risk/order_risk_adapter.rs
//!
//! ## 职责
//! 实现 OrderRiskPort，在下单前进行风控检查。
//! 使用 RiskContext + RiskRulesChecker 实现"有状态"的风控。
//!
//! ## 架构位置
//! - 所属服务: trading-engine
//! - 所属层级: Infrastructure Layer
//! - 被谁调用: ExecutionService
//! - 调用顺序: Strategy → OrderRiskAdapter → OrderExecutor → Exchange
//!
//! ## v1 实现的 5 条规则
//! 1. 熔断检查 - 连续 N 次拒绝后暂停交易
//! 2. 账户状态检查 - 账户是否允许交易
//! 3. 单笔最大名义价值 - 防止单笔过大
//! 4. 单 Symbol 最大仓位 - 防止单币种过度集中
//! 5. 重复订单检查 - 防止同方向重复下单

use std::collections::{HashMap, HashSet};
use std::sync::Arc;

use async_trait::async_trait;
use chrono::Utc;
use rust_decimal::Decimal;
use tokio::sync::RwLock;
use tracing::{debug, info, warn};

use crate::domain::logic::risk_rules::{RiskRejectReason, RiskRulesChecker, RiskRulesConfig};
use crate::domain::model::order_intent::{OrderIntent, OrderSide};
use crate::domain::model::risk_context::{
    AccountSnapshot, PendingOrder, PositionSnapshot, RiskContext, RiskStats,
};
use crate::domain::port::order_risk_port::OrderRiskPort;

// ============================================================================
// 风控配置
// ============================================================================

/// 风控适配器配置
#[derive(Debug, Clone)]
pub struct RiskAdapterConfig {
    /// 允许的交易对白名单（空 = 允许所有）
    pub allowed_symbols: HashSet<String>,
    /// 最小下单数量
    pub min_qty: Decimal,
    /// 最大下单数量
    pub max_qty: Decimal,
    /// 单笔最大名义价值
    pub max_notional: Decimal,
    /// 单 Symbol 最大仓位
    pub max_position: Decimal,
    /// 账户是否允许交易
    pub trading_enabled: bool,
    /// 触发熔断的连续拒绝次数
    pub circuit_breaker_threshold: u32,
    /// 熔断持续时间（秒）
    pub circuit_breaker_duration_secs: i64,
}

impl Default for RiskAdapterConfig {
    fn default() -> Self {
        Self {
            allowed_symbols: HashSet::new(),
            min_qty: Decimal::ZERO,
            max_qty: Decimal::new(100, 0),
            max_notional: Decimal::new(10000, 0),
            max_position: Decimal::new(10, 0),
            trading_enabled: true,
            circuit_breaker_threshold: 5,
            circuit_breaker_duration_secs: 300,
        }
    }
}

// ============================================================================
// 风控状态（内存态）
// ============================================================================

/// 风控内部状态
struct RiskInternalState {
    /// 当前持仓: symbol → quantity
    positions: HashMap<String, Decimal>,
    /// 未完成订单: symbol → Vec<PendingOrder>
    pending_orders: HashMap<String, Vec<PendingOrder>>,
    /// 风控统计
    risk_stats: RiskStats,
}

impl RiskInternalState {
    fn new() -> Self {
        Self {
            positions: HashMap::new(),
            pending_orders: HashMap::new(),
            risk_stats: RiskStats::default(),
        }
    }

    /// 构建 RiskContext 快照
    fn build_context(&self, config: &RiskAdapterConfig) -> RiskContext {
        let positions: HashMap<String, PositionSnapshot> = self
            .positions
            .iter()
            .map(|(symbol, qty)| {
                (
                    symbol.clone(),
                    PositionSnapshot {
                        symbol: symbol.clone(),
                        side: if *qty >= Decimal::ZERO {
                            OrderSide::Buy
                        } else {
                            OrderSide::Sell
                        },
                        quantity: qty.abs(),
                        avg_price: Decimal::ZERO, // v1 不跟踪均价
                        notional_value: Decimal::ZERO,
                        unrealized_pnl: Decimal::ZERO,
                        updated_at: Utc::now(),
                    },
                )
            })
            .collect();

        RiskContext {
            account: AccountSnapshot {
                trading_enabled: config.trading_enabled,
                available_balance: Decimal::ZERO, // v1 不跟踪余额
                total_balance: Decimal::ZERO,
                used_margin: Decimal::ZERO,
                leverage: 1,
                max_leverage: 20,
            },
            positions,
            pending_orders: self.pending_orders.clone(),
            risk_stats: self.risk_stats.clone(),
        }
    }
}

// ============================================================================
// 风控适配器实现
// ============================================================================

/// 订单风控适配器
///
/// 实现 OrderRiskPort，使用 RiskContext + RiskRulesChecker。
pub struct OrderRiskAdapter {
    config: RiskAdapterConfig,
    rules_checker: RiskRulesChecker,
    state: Arc<RwLock<RiskInternalState>>,
}

impl OrderRiskAdapter {
    /// 创建风控适配器
    pub fn new(config: RiskAdapterConfig) -> Self {
        let rules_config = RiskRulesConfig {
            max_notional_per_order: config.max_notional,
            max_position_per_symbol: config.max_position,
            circuit_breaker_threshold: config.circuit_breaker_threshold,
            circuit_breaker_duration_secs: config.circuit_breaker_duration_secs,
            allow_duplicate_orders: false,
        };

        Self {
            config,
            rules_checker: RiskRulesChecker::new(rules_config),
            state: Arc::new(RwLock::new(RiskInternalState::new())),
        }
    }

    /// 从环境变量创建（便捷方法）
    pub fn from_env(
        min_qty: Option<Decimal>,
        max_qty: Option<Decimal>,
        max_notional: Option<Decimal>,
        max_position: Option<Decimal>,
        _cooldown_ms: Option<u64>, // 保持接口兼容，v1 不使用
        allowed_symbols: Option<Vec<String>>,
    ) -> Self {
        let allowed_symbols = allowed_symbols
            .map(|items| {
                items
                    .into_iter()
                    .map(|s| s.trim().to_uppercase())
                    .filter(|s| !s.is_empty())
                    .collect()
            })
            .unwrap_or_default();

        let trading_enabled = std::env::var("TRADING_ENABLED")
            .map(|v| v.to_lowercase() != "false" && v != "0")
            .unwrap_or(true);

        let circuit_breaker_threshold: u32 = std::env::var("RISK_CIRCUIT_BREAKER_THRESHOLD")
            .ok()
            .and_then(|v| v.parse().ok())
            .unwrap_or(5);

        let circuit_breaker_duration: i64 = std::env::var("RISK_CIRCUIT_BREAKER_DURATION_SECS")
            .ok()
            .and_then(|v| v.parse().ok())
            .unwrap_or(300);

        let config = RiskAdapterConfig {
            allowed_symbols,
            min_qty: min_qty.unwrap_or(Decimal::ZERO),
            max_qty: max_qty.unwrap_or(Decimal::new(100, 0)),
            max_notional: max_notional.unwrap_or(Decimal::new(10000, 0)),
            max_position: max_position.unwrap_or(Decimal::new(10, 0)),
            trading_enabled,
            circuit_breaker_threshold,
            circuit_breaker_duration_secs: circuit_breaker_duration,
        };

        Self::new(config)
    }

    /// 前置检查：Symbol 白名单 + 数量范围
    fn pre_check(&self, intent: &OrderIntent) -> Result<(), RiskRejectReason> {
        let symbol = intent.symbol.trim().to_uppercase();

        // Symbol 白名单
        if !self.config.allowed_symbols.is_empty()
            && !self.config.allowed_symbols.contains(&symbol)
        {
            return Err(RiskRejectReason::SymbolNotAllowed { symbol });
        }

        // 最小数量
        if intent.quantity < self.config.min_qty {
            return Err(RiskRejectReason::QuantityBelowMinimum {
                quantity: intent.quantity,
                minimum: self.config.min_qty,
            });
        }

        // 最大数量
        if intent.quantity > self.config.max_qty {
            return Err(RiskRejectReason::QuantityAboveMaximum {
                quantity: intent.quantity,
                maximum: self.config.max_qty,
            });
        }

        Ok(())
    }
}

#[async_trait]
impl OrderRiskPort for OrderRiskAdapter {
    /// 检查交易意图是否符合风控要求
    async fn check(&self, intent: &OrderIntent) -> anyhow::Result<()> {
        // 1. 前置检查（Symbol 白名单 + 数量范围）
        if let Err(reason) = self.pre_check(intent) {
            info!(
                symbol = %intent.symbol,
                reject_reason = %reason,
                "RISK_REJECTED: pre-check failed"
            );
            // 记录拒绝
            let mut state = self.state.write().await;
            state.risk_stats.record_reject();
            // 检查是否需要触发熔断
            if state.risk_stats.consecutive_rejects >= self.config.circuit_breaker_threshold {
                state.risk_stats.trigger_circuit_breaker(self.config.circuit_breaker_duration_secs);
                warn!(
                    consecutive_rejects = state.risk_stats.consecutive_rejects,
                    duration_secs = self.config.circuit_breaker_duration_secs,
                    "CIRCUIT_BREAKER_TRIGGERED"
                );
            }
            return Err(anyhow::Error::new(reason));
        }

        // 2. 构建 RiskContext
        let mut state = self.state.write().await;
        
        // 检查并解除熔断
        state.risk_stats.check_circuit_breaker();
        
        let context = state.build_context(&self.config);

        // 3. 执行规则检查
        match self.rules_checker.check_all(intent, &context) {
            Ok(()) => {
                debug!(
                    symbol = %intent.symbol,
                    quantity = %intent.quantity,
                    "RISK_PASSED: all rules passed"
                );
                Ok(())
            }
            Err(reason) => {
                info!(
                    symbol = %intent.symbol,
                    side = ?intent.side,
                    quantity = %intent.quantity,
                    reject_reason = %reason,
                    "RISK_REJECTED: rule check failed"
                );
                // 记录拒绝
                state.risk_stats.record_reject();
                // 检查是否需要触发熔断
                if state.risk_stats.consecutive_rejects >= self.config.circuit_breaker_threshold {
                    state.risk_stats.trigger_circuit_breaker(self.config.circuit_breaker_duration_secs);
                    warn!(
                        consecutive_rejects = state.risk_stats.consecutive_rejects,
                        duration_secs = self.config.circuit_breaker_duration_secs,
                        "CIRCUIT_BREAKER_TRIGGERED"
                    );
                }
                Err(anyhow::Error::new(reason))
            }
        }
    }

    /// 更新持仓（下单成功后调用）
    async fn update_position(&self, symbol: &str, delta: Decimal) {
        let symbol = symbol.trim().to_uppercase();
        let mut state = self.state.write().await;

        let current = state.positions.get(&symbol).copied().unwrap_or(Decimal::ZERO);
        let new_position = current + delta;

        if new_position.is_zero() {
            state.positions.remove(&symbol);
        } else {
            state.positions.insert(symbol.clone(), new_position);
        }

        // 记录成功，重置连续拒绝计数
        state.risk_stats.record_success();

        debug!(
            symbol = %symbol,
            delta = %delta,
            new_position = %new_position,
            "Position updated"
        );
    }

    /// 记录下单时间（下单成功后调用）
    async fn record_order_time(&self, symbol: &str) {
        let symbol = symbol.trim().to_uppercase();
        debug!(symbol = %symbol, "Order time recorded");
        // v1 不实现冷却时间，预留接口
    }
}

// ============================================================================
// 注意: RiskRejectReason 从 domain::logic::risk_rules 导入使用
// 外部模块应从 crate::domain::logic::risk_rules 或 infrastructure::risk 导入
// ============================================================================