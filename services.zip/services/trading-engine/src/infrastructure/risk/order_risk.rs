//! # 订单风控适配器 (Order Risk Adapter)
//!
//! 实现 OrderRiskPort，检查 OrderIntent 是否符合风控要求。

use std::collections::HashSet;

use anyhow::anyhow;
use async_trait::async_trait;
use rust_decimal::Decimal;
use tracing::debug;

use crate::domain::model::order_intent::OrderIntent;
use crate::domain::port::order_risk_port::OrderRiskPort;

/// 订单风控配置
#[derive(Debug, Clone)]
pub struct OrderRiskConfig {
    /// 最小数量
    pub min_qty: Option<Decimal>,
    /// 最大数量
    pub max_qty: Option<Decimal>,
    /// 最大名义价值
    pub max_notional: Option<Decimal>,
    /// 允许的交易对
    pub allow_symbols: Option<HashSet<String>>,
}

/// 订单风控适配器
pub struct OrderRiskAdapter {
    config: OrderRiskConfig,
}

impl OrderRiskAdapter {
    /// 创建订单风控适配器
    pub fn new(
        min_qty: Option<Decimal>,
        max_qty: Option<Decimal>,
        max_notional: Option<Decimal>,
        allow_symbols: Option<Vec<String>>,
    ) -> Self {
        let allow_symbols = allow_symbols.map(|items| {
            items
                .into_iter()
                .map(|s| s.trim().to_uppercase())
                .filter(|s| !s.is_empty())
                .collect()
        });

        Self {
            config: OrderRiskConfig {
                min_qty,
                max_qty,
                max_notional,
                allow_symbols,
            },
        }
    }
}

#[async_trait]
impl OrderRiskPort for OrderRiskAdapter {
    async fn check(&self, intent: &OrderIntent) -> anyhow::Result<()> {
        let symbol = intent.symbol.trim().to_uppercase();

        // 规则1: 交易对白名单
        if let Some(allow) = &self.config.allow_symbols {
            if !allow.contains(&symbol) {
                return Err(anyhow!("symbol {} not allowed", symbol));
            }
        }

        // 规则2: 最小数量
        if let Some(min_qty) = &self.config.min_qty {
            if intent.quantity < *min_qty {
                return Err(anyhow!(
                    "quantity {} below min {}",
                    intent.quantity,
                    min_qty
                ));
            }
        }

        // 规则3: 最大数量
        if let Some(max_qty) = &self.config.max_qty {
            if intent.quantity > *max_qty {
                return Err(anyhow!(
                    "quantity {} above max {}",
                    intent.quantity,
                    max_qty
                ));
            }
        }

        // 规则4: 最大名义价值
        if let Some(max_notional) = &self.config.max_notional {
            if let Some(price) = intent.price {
                let notional = intent.quantity * price;
                if notional > *max_notional {
                    return Err(anyhow!(
                        "notional {} above max {}",
                        notional,
                        max_notional
                    ));
                }
            }
        }

        debug!(
            symbol = %symbol,
            quantity = %intent.quantity,
            "Order intent passed risk check"
        );

        Ok(())
    }
}
