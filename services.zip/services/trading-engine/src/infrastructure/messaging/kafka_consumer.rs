//! 交易信号的 Kafka 消费者适配器。

use anyhow::{anyhow, Context};
use async_trait::async_trait;
use rdkafka::config::ClientConfig;
use rdkafka::consumer::{CommitMode, Consumer, StreamConsumer};
use rdkafka::Message;
use shared::event::signal_event::SignalEvent;

use crate::domain::port::signal_port::SignalPort;

pub struct KafkaConsumer {
    #[allow(dead_code)]
    brokers: String,
    #[allow(dead_code)]
    topic: String,
    #[allow(dead_code)]
    group_id: String,
    consumer: StreamConsumer,
}

impl KafkaConsumer {
    pub fn new(brokers: String, topic: String, group_id: String) -> anyhow::Result<Self> {
        let consumer: StreamConsumer = ClientConfig::new()
            .set("bootstrap.servers", &brokers)
            .set("group.id", &group_id)
            .set("enable.auto.commit", "true")
            .set("auto.offset.reset", "latest")
            .create()
            .context("failed to create kafka consumer")?;

        consumer
            .subscribe(&[&topic])
            .context("failed to subscribe kafka topic")?;

        Ok(Self {
            brokers,
            topic,
            group_id,
            consumer,
        })
    }
}

#[async_trait]
impl SignalPort for KafkaConsumer {
    async fn next_signal(&self) -> anyhow::Result<SignalEvent> {
        let message = self
            .consumer
            .recv()
            .await
            .context("failed to receive kafka message")?;

        let payload = message
            .payload()
            .ok_or_else(|| anyhow!("kafka message payload is empty"))?;
        let event: SignalEvent =
            serde_json::from_slice(payload).context("deserialize signal event")?;

        self.consumer
            .commit_message(&message, CommitMode::Async)
            .context("commit kafka message")?;

        Ok(event)
    }
}
