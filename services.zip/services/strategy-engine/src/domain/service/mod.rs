//! # 领域服务 (Domain Services)

/// 信号生成器 - 跨模型规则
pub mod signal_generator;
