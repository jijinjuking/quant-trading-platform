//! # 策略评估处理器 (Evaluate Handler)
//!
//! 处理策略评估请求，供 trading-engine 调用。
//!
//! ## API
//! - `POST /api/v1/strategy/evaluate`: 评估策略，返回交易意图

use axum::{extract::State, Json};
use chrono::Utc;
use tracing::{debug, warn};

use crate::domain::logic::grid::{calculate_grid_signal, GridState};
use crate::domain::logic::mean::{calculate_mean_reversion_signal, MeanReversionState};
use crate::domain::model::signal::SignalType;
use crate::interface::http::dto::{
    ApiResponse, EvaluateRequest, EvaluateResponse, OrderIntentDto,
};
use crate::state::AppState;
use shared::event::market_event::{MarketEvent, MarketEventData, MarketEventType, TradeData};

/// POST /api/v1/strategy/evaluate
///
/// 评估策略，根据行情生成交易意图。
/// 这是 trading-engine 调用的核心 API。
pub async fn evaluate_strategy(
    State(state): State<AppState>,
    Json(req): Json<EvaluateRequest>,
) -> Json<ApiResponse<EvaluateResponse>> {
    debug!(
        "收到策略评估请求: strategy_id={}, symbol={}, price={}",
        req.strategy_id, req.symbol, req.price
    );

    // 构造 MarketEvent
    let market_event = MarketEvent {
        event_type: MarketEventType::Trade,
        exchange: "binance".to_string(),
        symbol: req.symbol.clone(),
        timestamp: Utc::now(),
        data: MarketEventData::Trade(TradeData {
            trade_id: req.timestamp.to_string(),
            price: req.price,
            quantity: req.quantity,
            is_buyer_maker: req.is_buyer_maker,
        }),
    };

    // 根据配置的策略类型评估
    let signal = evaluate_with_config_strategy(&state, &market_event);

    // 转换为响应
    let response = match signal {
        Some(sig) => {
            let side = match sig.signal_type {
                SignalType::Buy => "buy",
                SignalType::Sell => "sell",
                SignalType::Hold => "hold",
            };

            // Hold 信号不生成交易意图
            if matches!(sig.signal_type, SignalType::Hold) {
                EvaluateResponse {
                    has_intent: false,
                    intent: None,
                }
            } else {
                EvaluateResponse {
                    has_intent: true,
                    intent: Some(OrderIntentDto {
                        id: sig.id,
                        strategy_id: sig.strategy_id,
                        symbol: sig.symbol,
                        side: side.to_string(),
                        quantity: sig.quantity,
                        price: Some(sig.price),
                        order_type: "limit".to_string(),
                        confidence: sig.confidence,
                        created_at: Utc::now().timestamp_millis(),
                    }),
                }
            }
        }
        None => EvaluateResponse {
            has_intent: false,
            intent: None,
        },
    };

    Json(ApiResponse::ok(response))
}

/// 使用配置的策略进行评估
fn evaluate_with_config_strategy(
    state: &AppState,
    event: &MarketEvent,
) -> Option<crate::domain::model::signal::Signal> {
    use crate::domain::model::strategy_config::StrategyType;

    let config = &state.config;

    match config.strategy_type {
        StrategyType::Grid => {
            // 注意：这里每次请求创建新状态，实际应该持久化状态
            let mut grid_state = GridState::new();
            calculate_grid_signal(event, &config.grid_config, &mut grid_state)
        }
        StrategyType::MeanReversion => {
            // 注意：这里每次请求创建新状态，实际应该持久化状态
            let mut mean_state = MeanReversionState::new();
            calculate_mean_reversion_signal(event, &config.mean_reversion_config, &mut mean_state)
        }
    }
}

/// POST /api/v1/strategy/evaluate/batch
///
/// 批量评估多个策略（预留接口）
#[allow(dead_code)]
pub async fn evaluate_batch() -> Json<ApiResponse<Vec<EvaluateResponse>>> {
    warn!("批量评估接口尚未实现");
    Json(ApiResponse::err("批量评估接口尚未实现"))
}
