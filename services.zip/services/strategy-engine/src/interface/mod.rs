//! # 接口层 (Interface Layer)
//! 
//! 处理外部请求的入口层。

/// HTTP 接口模块
pub mod http;
