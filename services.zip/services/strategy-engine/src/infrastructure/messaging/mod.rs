//! # 消息队列基础设施 (Messaging Infrastructure)

/// Kafka 生产者 - 发布交易信号
pub mod kafka_producer;
