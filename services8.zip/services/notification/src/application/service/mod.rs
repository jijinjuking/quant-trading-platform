//! # 应用服务模块
//!
//! 本文件导出所有应用层服务。
//!
//! ## 子模块
//! - `notification_service`: 通知应用服务

/// 通知应用服务模块
pub mod notification_service;
