//! # 应用层 (Application Layer)
//! 
//! 用例编排层。

/// 应用服务
pub mod service;
