//! # 策略运行时 (Strategy Runtime)
//!
//! 管理单个策略实例的 Task 生命周期。
//!
//! ## 工程约束
//! - 每个策略实例对应一个独立 Task
//! - Task 通过 mpsc 通道接收命令
//! - Task 通过 watch 通道广播状态
//! - Task panic 时自动标记为 Faulted
//!
//! ## 并发保护
//! - 同一策略实例不允许并发执行
//! - 命令按顺序处理（FIFO）

use std::panic::AssertUnwindSafe;
use std::sync::Arc;

use anyhow::{anyhow, Result};
use futures::future::FutureExt;
use tokio::sync::{mpsc, oneshot, watch};
use tokio::task::JoinHandle;
use tracing::{debug, error, info, warn};
use uuid::Uuid;

use super::strategy_command::{StrategyCommand, StrategyStatus};
use super::strategy_handle::{ExecutionRequest, ExecutionResult};
use crate::domain::port::strategy_executor_port::StrategyExecutorPort;

/// 策略运行时配置
#[derive(Debug, Clone)]
pub struct RuntimeConfig {
    /// 命令通道缓冲区大小
    pub command_buffer_size: usize,
    /// 执行超时（毫秒）
    pub execution_timeout_ms: u64,
}

impl Default for RuntimeConfig {
    fn default() -> Self {
        Self {
            command_buffer_size: 64,
            execution_timeout_ms: 5000,
        }
    }
}

/// 策略运行时句柄
///
/// 持有与策略 Task 通信的通道和 JoinHandle。
/// Registry 只管理这个句柄，不直接管理策略逻辑。
pub struct StrategyRuntimeHandle {
    /// 策略实例 ID
    instance_id: Uuid,
    /// 命令发送通道
    command_tx: mpsc::Sender<StrategyCommand>,
    /// 状态监听通道
    status_rx: watch::Receiver<StrategyStatus>,
    /// Task 句柄
    task_handle: JoinHandle<()>,
}

impl StrategyRuntimeHandle {
    /// 获取实例 ID
    pub fn instance_id(&self) -> Uuid {
        self.instance_id
    }

    /// 获取当前状态
    pub fn status(&self) -> StrategyStatus {
        *self.status_rx.borrow()
    }

    /// 等待状态变化
    pub async fn wait_for_status_change(&mut self) -> Result<StrategyStatus> {
        self.status_rx
            .changed()
            .await
            .map_err(|_| anyhow!("状态通道已关闭"))?;
        Ok(*self.status_rx.borrow())
    }

    /// 发送执行请求
    pub async fn execute(&self, request: ExecutionRequest) -> Result<ExecutionResult> {
        let status = self.status();
        if !status.can_execute() {
            return Err(anyhow!(
                "策略 {} 当前状态 {} 不允许执行",
                self.instance_id,
                status
            ));
        }

        let (response_tx, response_rx) = oneshot::channel();
        self.command_tx
            .send(StrategyCommand::Execute {
                request,
                response_tx,
            })
            .await
            .map_err(|_| anyhow!("命令通道已关闭"))?;

        response_rx
            .await
            .map_err(|_| anyhow!("响应通道已关闭"))?
    }

    /// 暂停策略
    pub async fn pause(&self) -> Result<()> {
        let status = self.status();
        if !status.can_pause() {
            return Err(anyhow!(
                "策略 {} 当前状态 {} 不允许暂停",
                self.instance_id,
                status
            ));
        }

        let (response_tx, response_rx) = oneshot::channel();
        self.command_tx
            .send(StrategyCommand::Pause { response_tx })
            .await
            .map_err(|_| anyhow!("命令通道已关闭"))?;

        response_rx
            .await
            .map_err(|_| anyhow!("响应通道已关闭"))?
    }

    /// 恢复策略
    pub async fn resume(&self) -> Result<()> {
        let status = self.status();
        if !status.can_resume() {
            return Err(anyhow!(
                "策略 {} 当前状态 {} 不允许恢复",
                self.instance_id,
                status
            ));
        }

        let (response_tx, response_rx) = oneshot::channel();
        self.command_tx
            .send(StrategyCommand::Resume { response_tx })
            .await
            .map_err(|_| anyhow!("命令通道已关闭"))?;

        response_rx
            .await
            .map_err(|_| anyhow!("响应通道已关闭"))?
    }

    /// 重置策略状态
    pub async fn reset(&self) -> Result<()> {
        let (response_tx, response_rx) = oneshot::channel();
        self.command_tx
            .send(StrategyCommand::Reset { response_tx })
            .await
            .map_err(|_| anyhow!("命令通道已关闭"))?;

        response_rx
            .await
            .map_err(|_| anyhow!("响应通道已关闭"))?
    }

    /// 获取状态快照
    pub async fn state_snapshot(&self) -> Result<serde_json::Value> {
        let (response_tx, response_rx) = oneshot::channel();
        self.command_tx
            .send(StrategyCommand::GetStateSnapshot { response_tx })
            .await
            .map_err(|_| anyhow!("命令通道已关闭"))?;

        response_rx
            .await
            .map_err(|_| anyhow!("响应通道已关闭"))?
    }

    /// 关闭策略 Task
    pub async fn shutdown(&self) -> Result<()> {
        // 发送关闭命令（忽略发送失败，可能已经关闭）
        let _ = self.command_tx.send(StrategyCommand::Shutdown).await;
        Ok(())
    }

    /// 等待 Task 结束
    pub async fn wait_for_shutdown(self) -> Result<()> {
        self.task_handle
            .await
            .map_err(|e| anyhow!("Task join 失败: {}", e))
    }

    /// 检查 Task 是否已结束
    pub fn is_finished(&self) -> bool {
        self.task_handle.is_finished()
    }

    /// 强制终止 Task
    pub fn abort(&self) {
        self.task_handle.abort();
    }
}

/// 启动策略运行时
///
/// 创建一个独立的 Tokio Task 来运行策略。
///
/// # 参数
/// - `instance_id`: 策略实例 ID
/// - `executor`: 策略执行器
/// - `config`: 运行时配置
///
/// # 返回
/// - `StrategyRuntimeHandle`: 运行时句柄
pub fn spawn_strategy_runtime(
    instance_id: Uuid,
    executor: Arc<dyn StrategyExecutorPort>,
    config: RuntimeConfig,
) -> StrategyRuntimeHandle {
    let (command_tx, command_rx) = mpsc::channel(config.command_buffer_size);
    let (status_tx, status_rx) = watch::channel(StrategyStatus::Initializing);

    let task_handle = tokio::spawn(strategy_task_loop(
        instance_id,
        executor,
        command_rx,
        status_tx,
        config,
    ));

    info!(instance_id = %instance_id, "策略运行时已启动");

    StrategyRuntimeHandle {
        instance_id,
        command_tx,
        status_rx,
        task_handle,
    }
}

/// 策略 Task 主循环
async fn strategy_task_loop(
    instance_id: Uuid,
    executor: Arc<dyn StrategyExecutorPort>,
    mut command_rx: mpsc::Receiver<StrategyCommand>,
    status_tx: watch::Sender<StrategyStatus>,
    config: RuntimeConfig,
) {
    // 初始化完成，进入运行状态
    let _ = status_tx.send(StrategyStatus::Running);
    info!(instance_id = %instance_id, "策略 Task 进入运行状态");

    let mut is_paused = false;

    loop {
        let command = match command_rx.recv().await {
            Some(cmd) => cmd,
            None => {
                // 通道关闭，退出
                warn!(instance_id = %instance_id, "命令通道已关闭，策略 Task 退出");
                break;
            }
        };

        debug!(instance_id = %instance_id, command = ?command, "收到命令");

        match command {
            StrategyCommand::Execute {
                request,
                response_tx,
            } => {
                if is_paused {
                    let _ = response_tx.send(Err(anyhow!("策略已暂停")));
                    continue;
                }

                // 使用 catch_unwind 捕获 panic
                let executor_clone = Arc::clone(&executor);
                let result = AssertUnwindSafe(async {
                    // 同步执行策略计算（在当前 Task 中）
                    executor_clone.execute(&request)
                })
                .catch_unwind()
                .await;

                match result {
                    Ok(exec_result) => {
                        let _ = response_tx.send(exec_result);
                    }
                    Err(panic_info) => {
                        let panic_msg = if let Some(s) = panic_info.downcast_ref::<&str>() {
                            s.to_string()
                        } else if let Some(s) = panic_info.downcast_ref::<String>() {
                            s.clone()
                        } else {
                            "Unknown panic".to_string()
                        };

                        error!(
                            instance_id = %instance_id,
                            panic = %panic_msg,
                            "策略执行 panic"
                        );

                        // 标记为故障状态
                        let _ = status_tx.send(StrategyStatus::Faulted);
                        let _ = response_tx.send(Err(anyhow!("策略执行 panic: {}", panic_msg)));

                        // 故障后退出 Task
                        break;
                    }
                }
            }

            StrategyCommand::Pause { response_tx } => {
                if is_paused {
                    let _ = response_tx.send(Err(anyhow!("策略已经处于暂停状态")));
                } else {
                    is_paused = true;
                    let _ = status_tx.send(StrategyStatus::Paused);
                    info!(instance_id = %instance_id, "策略已暂停");
                    let _ = response_tx.send(Ok(()));
                }
            }

            StrategyCommand::Resume { response_tx } => {
                if !is_paused {
                    let _ = response_tx.send(Err(anyhow!("策略未处于暂停状态")));
                } else {
                    is_paused = false;
                    let _ = status_tx.send(StrategyStatus::Running);
                    info!(instance_id = %instance_id, "策略已恢复");
                    let _ = response_tx.send(Ok(()));
                }
            }

            StrategyCommand::Reset { response_tx } => {
                let result = executor.reset();
                if let Err(ref e) = result {
                    error!(instance_id = %instance_id, error = %e, "策略重置失败");
                } else {
                    info!(instance_id = %instance_id, "策略已重置");
                }
                let _ = response_tx.send(result);
            }

            StrategyCommand::GetStateSnapshot { response_tx } => {
                let result = executor.state_snapshot();
                let _ = response_tx.send(result);
            }

            StrategyCommand::Shutdown => {
                info!(instance_id = %instance_id, "收到关闭命令，策略 Task 退出");
                let _ = status_tx.send(StrategyStatus::Stopped);
                break;
            }
        }
    }

    // 确保最终状态正确
    let final_status = *status_tx.borrow();
    if final_status != StrategyStatus::Stopped && final_status != StrategyStatus::Faulted {
        let _ = status_tx.send(StrategyStatus::Stopped);
    }

    info!(instance_id = %instance_id, "策略 Task 已退出");
}

#[cfg(test)]
mod tests {
    use super::*;
    use parking_lot::Mutex;
    use rust_decimal::Decimal;

    /// 测试用执行器
    struct TestExecutor {
        call_count: Mutex<u32>,
        should_fail: Mutex<bool>,
        should_panic: Mutex<bool>,
    }

    impl TestExecutor {
        fn new() -> Self {
            Self {
                call_count: Mutex::new(0),
                should_fail: Mutex::new(false),
                should_panic: Mutex::new(false),
            }
        }

        fn set_should_fail(&self, fail: bool) {
            *self.should_fail.lock() = fail;
        }

        fn set_should_panic(&self, panic: bool) {
            *self.should_panic.lock() = panic;
        }

        fn call_count(&self) -> u32 {
            *self.call_count.lock()
        }
    }

    impl StrategyExecutorPort for TestExecutor {
        fn execute(
            &self,
            request: &ExecutionRequest,
        ) -> Result<ExecutionResult> {
            *self.call_count.lock() += 1;

            if *self.should_panic.lock() {
                panic!("测试 panic");
            }

            if *self.should_fail.lock() {
                return Err(anyhow!("测试错误"));
            }

            Ok(ExecutionResult {
                request_id: request.request_id,
                has_intent: false,
                intent: None,
                execution_time_us: 0,
                error: None,
            })
        }

        fn reset(&self) -> Result<()> {
            *self.call_count.lock() = 0;
            Ok(())
        }

        fn state_snapshot(&self) -> Result<serde_json::Value> {
            Ok(serde_json::json!({
                "call_count": *self.call_count.lock()
            }))
        }
    }

    fn create_test_request() -> ExecutionRequest {
        ExecutionRequest::new("BTCUSDT", Decimal::new(50000, 0), Decimal::new(1, 3))
    }

    #[tokio::test]
    async fn test_spawn_and_execute() {
        let instance_id = Uuid::new_v4();
        let executor = Arc::new(TestExecutor::new());
        let handle = spawn_strategy_runtime(
            instance_id,
            Arc::clone(&executor) as Arc<dyn StrategyExecutorPort>,
            RuntimeConfig::default(),
        );

        // 等待进入运行状态
        tokio::time::sleep(tokio::time::Duration::from_millis(10)).await;
        assert_eq!(handle.status(), StrategyStatus::Running);

        // 执行请求
        let request = create_test_request();
        let result = handle.execute(request).await;
        assert!(result.is_ok());
        assert_eq!(executor.call_count(), 1);

        // 关闭
        handle.shutdown().await.unwrap();
        handle.wait_for_shutdown().await.unwrap();
    }

    #[tokio::test]
    async fn test_pause_and_resume() {
        let instance_id = Uuid::new_v4();
        let executor = Arc::new(TestExecutor::new());
        let handle = spawn_strategy_runtime(
            instance_id,
            executor as Arc<dyn StrategyExecutorPort>,
            RuntimeConfig::default(),
        );

        tokio::time::sleep(tokio::time::Duration::from_millis(10)).await;

        // 暂停
        handle.pause().await.unwrap();
        assert_eq!(handle.status(), StrategyStatus::Paused);

        // 暂停状态下执行应该失败
        let request = create_test_request();
        let result = handle.execute(request).await;
        assert!(result.is_err());

        // 恢复
        handle.resume().await.unwrap();
        assert_eq!(handle.status(), StrategyStatus::Running);

        // 恢复后可以执行
        let request = create_test_request();
        let result = handle.execute(request).await;
        assert!(result.is_ok());

        handle.shutdown().await.unwrap();
    }

    #[tokio::test]
    async fn test_panic_handling() {
        let instance_id = Uuid::new_v4();
        let executor = Arc::new(TestExecutor::new());
        executor.set_should_panic(true);

        let handle = spawn_strategy_runtime(
            instance_id,
            Arc::clone(&executor) as Arc<dyn StrategyExecutorPort>,
            RuntimeConfig::default(),
        );

        tokio::time::sleep(tokio::time::Duration::from_millis(10)).await;

        // 执行会触发 panic
        let request = create_test_request();
        let result = handle.execute(request).await;
        assert!(result.is_err());

        // 等待状态变为 Faulted
        tokio::time::sleep(tokio::time::Duration::from_millis(10)).await;
        assert_eq!(handle.status(), StrategyStatus::Faulted);

        // Task 应该已经结束
        assert!(handle.is_finished());
    }

    #[tokio::test]
    async fn test_reset() {
        let instance_id = Uuid::new_v4();
        let executor = Arc::new(TestExecutor::new());
        let handle = spawn_strategy_runtime(
            instance_id,
            Arc::clone(&executor) as Arc<dyn StrategyExecutorPort>,
            RuntimeConfig::default(),
        );

        tokio::time::sleep(tokio::time::Duration::from_millis(10)).await;

        // 执行几次
        for _ in 0..3 {
            let request = create_test_request();
            handle.execute(request).await.unwrap();
        }
        assert_eq!(executor.call_count(), 3);

        // 重置
        handle.reset().await.unwrap();
        assert_eq!(executor.call_count(), 0);

        handle.shutdown().await.unwrap();
    }
}
