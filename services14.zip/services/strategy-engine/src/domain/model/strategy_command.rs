//! # 策略命令 (Strategy Command)
//!
//! 定义策略 Task 接收的命令类型。
//!
//! ## 工程约束
//! - 命令通过 mpsc 通道发送
//! - 每个命令都有明确的语义
//! - 支持请求-响应模式

use serde::{Deserialize, Serialize};
use tokio::sync::oneshot;

use super::strategy_handle::{ExecutionRequest, ExecutionResult};

/// 策略命令
///
/// 通过 mpsc 通道发送给策略 Task。
pub enum StrategyCommand {
    /// 执行策略计算
    Execute {
        /// 执行请求
        request: ExecutionRequest,
        /// 响应通道
        response_tx: oneshot::Sender<anyhow::Result<ExecutionResult>>,
    },

    /// 暂停策略
    Pause {
        /// 响应通道
        response_tx: oneshot::Sender<anyhow::Result<()>>,
    },

    /// 恢复策略
    Resume {
        /// 响应通道
        response_tx: oneshot::Sender<anyhow::Result<()>>,
    },

    /// 重置策略状态
    Reset {
        /// 响应通道
        response_tx: oneshot::Sender<anyhow::Result<()>>,
    },

    /// 获取状态快照
    GetStateSnapshot {
        /// 响应通道
        response_tx: oneshot::Sender<anyhow::Result<serde_json::Value>>,
    },

    /// 关闭策略 Task
    Shutdown,
}

impl std::fmt::Debug for StrategyCommand {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            StrategyCommand::Execute { request, .. } => {
                write!(f, "Execute(request_id={})", request.request_id)
            }
            StrategyCommand::Pause { .. } => write!(f, "Pause"),
            StrategyCommand::Resume { .. } => write!(f, "Resume"),
            StrategyCommand::Reset { .. } => write!(f, "Reset"),
            StrategyCommand::GetStateSnapshot { .. } => write!(f, "GetStateSnapshot"),
            StrategyCommand::Shutdown => write!(f, "Shutdown"),
        }
    }
}

/// 策略状态（通过 watch 通道广播）
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum StrategyStatus {
    /// 初始化中
    Initializing,
    /// 运行中
    Running,
    /// 已暂停
    Paused,
    /// 已停止
    Stopped,
    /// 故障
    Faulted,
}

impl Default for StrategyStatus {
    fn default() -> Self {
        StrategyStatus::Initializing
    }
}

impl std::fmt::Display for StrategyStatus {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            StrategyStatus::Initializing => write!(f, "initializing"),
            StrategyStatus::Running => write!(f, "running"),
            StrategyStatus::Paused => write!(f, "paused"),
            StrategyStatus::Stopped => write!(f, "stopped"),
            StrategyStatus::Faulted => write!(f, "faulted"),
        }
    }
}

impl StrategyStatus {
    /// 是否可以接受执行请求
    pub fn can_execute(&self) -> bool {
        matches!(self, StrategyStatus::Running)
    }

    /// 是否可以暂停
    pub fn can_pause(&self) -> bool {
        matches!(self, StrategyStatus::Running)
    }

    /// 是否可以恢复
    pub fn can_resume(&self) -> bool {
        matches!(self, StrategyStatus::Paused)
    }

    /// 是否处于终态
    pub fn is_terminal(&self) -> bool {
        matches!(self, StrategyStatus::Stopped | StrategyStatus::Faulted)
    }
}
