//! # 行情消费服务组装
//!
//! 路径: services/trading-engine/src/bootstrap/consumer.rs
//!
//! ## 职责
//! 组装 MarketEventConsumerService（交易主链路入口）
//!
//! ## 交易主链路
//! ```text
//! MarketEvent → ExecutionFlowService → Strategy → Risk(远程) → Execution
//! ```

use std::sync::Arc;

use crate::domain::port::order_repository_port::OrderRepositoryPort;
use crate::domain::port::trade_audit_port::TradeAuditPort;
use crate::infrastructure::messaging::MarketEventKafkaConsumer;
use crate::infrastructure::repository::PostgresOrderRepository;
use crate::infrastructure::audit::NoopAuditAdapter;
use crate::application::service::execution_service::ExecutionService;
use crate::application::service::market_event_consumer_service::MarketEventConsumerService;

use super::database::create_postgres_pool;
use super::strategy::create_strategy_port;
use super::risk::{create_risk_port, create_risk_state};
use super::execution::{create_execution_port, create_order_execution_port};

/// 行情消费服务配置
#[derive(Debug, Clone)]
pub struct ConsumerConfig {
    // Kafka 配置
    pub kafka_brokers: String,
    pub kafka_market_topic: String,
    pub kafka_consumer_group: String,
    // 策略配置
    pub strategy_mode: String,
    pub strategy_url: Option<String>,
    // 执行配置
    pub execution_mode: String,
    pub binance_api_key: Option<String>,
    pub binance_secret_key: Option<String>,
    pub binance_base_url: String,
    // 风控配置
    pub risk_url: Option<String>,
    // 存储配置
    pub storage_enabled: bool,
}

/// 创建行情事件消费服务（交易主链路）
///
/// 这是交易主链路的入口：
/// MarketEvent → ExecutionFlowService → Strategy → Risk(远程) → Execution
///
/// # 风控说明
/// 风控逻辑已完全迁移到 risk-management 服务 (8085)
/// trading-engine 只通过 HTTP 调用远程风控，不包含任何风控规则
///
/// # 风控状态管理
/// - 启动时从 ExchangeQueryPort 同步初始状态到 RiskStatePort
/// - 运行期只有 ExecutionService 可以修改 RiskStatePort
/// - OrderRiskAdapter 只读取 RiskStatePort，不写入
pub async fn create_market_event_consumer(
    config: ConsumerConfig,
) -> anyhow::Result<MarketEventConsumerService> {
    // 1. 创建行情事件源
    let source = Arc::new(MarketEventKafkaConsumer::new(
        config.kafka_brokers,
        config.kafka_market_topic,
        config.kafka_consumer_group,
    )?);

    // 2. 创建策略端口
    let strategy = create_strategy_port(&config.strategy_mode, config.strategy_url)?;

    // 3. 创建风控端口（远程模式）
    let risk = create_risk_port(config.risk_url);

    // 4. 创建执行端口
    let inner_execution = create_execution_port(
        &config.execution_mode,
        config.binance_api_key.clone(),
        config.binance_secret_key.clone(),
        config.binance_base_url.clone(),
    )?;
    let execution = create_order_execution_port(inner_execution);

    // 5. 创建审计端口（v1 使用 Noop，只打日志）
    let audit: Arc<dyn TradeAuditPort> = Arc::new(NoopAuditAdapter::new());
    tracing::info!("交易审计已启用 (noop mode)");

    // 6. 创建并初始化 RiskStatePort
    let risk_state = Some(create_risk_state(
        config.binance_api_key,
        config.binance_secret_key,
        config.binance_base_url,
    ).await);

    // 7. 创建 ExecutionService（核心调度）
    let execution_service = if config.storage_enabled {
        // 尝试创建数据库连接池
        match create_postgres_pool().await {
            Ok(pool) => {
                let order_repo: Arc<dyn OrderRepositoryPort> = 
                    Arc::new(PostgresOrderRepository::new(pool));
                tracing::info!("订单存储已启用");
                Arc::new(ExecutionService::with_full_config(
                    strategy, risk, execution, risk_state, Some(order_repo), Some(audit),
                ))
            }
            Err(e) => {
                tracing::warn!("无法连接数据库，订单存储已禁用: {}", e);
                Arc::new(ExecutionService::with_full_config(
                    strategy, risk, execution, risk_state, None, Some(audit),
                ))
            }
        }
    } else {
        tracing::info!("订单存储已禁用");
        Arc::new(ExecutionService::with_full_config(
            strategy, risk, execution, risk_state, None, Some(audit),
        ))
    };

    // 8. 创建 MarketEventConsumerService
    Ok(MarketEventConsumerService::new(source, execution_service))
}

// ============================================================================
// 向后兼容的旧接口（保留参数签名）
// ============================================================================

/// 创建行情事件消费服务（向后兼容接口）
///
/// 此函数保留原有的参数签名，内部转换为新的 ConsumerConfig 结构。
#[allow(clippy::too_many_arguments)]
pub async fn create_market_event_consumer_compat(
    brokers: String,
    market_topic: String,
    group_id: String,
    strategy_mode: String,
    strategy_url: Option<String>,
    execution_mode: String,
    binance_api_key: Option<String>,
    binance_secret_key: Option<String>,
    binance_base_url: String,
    _risk_mode: String,  // 保留参数兼容性，但只使用远程模式
    risk_url: Option<String>,
    _risk_min_qty: Option<rust_decimal::Decimal>,  // 已迁移到 risk-management
    _risk_max_qty: Option<rust_decimal::Decimal>,  // 已迁移到 risk-management
    _risk_max_notional: Option<rust_decimal::Decimal>,  // 已迁移到 risk-management
    _risk_allow_symbols: Option<Vec<String>>,  // 已迁移到 risk-management
    storage_enabled: bool,
) -> anyhow::Result<MarketEventConsumerService> {
    let config = ConsumerConfig {
        kafka_brokers: brokers,
        kafka_market_topic: market_topic,
        kafka_consumer_group: group_id,
        strategy_mode,
        strategy_url,
        execution_mode,
        binance_api_key,
        binance_secret_key,
        binance_base_url,
        risk_url,
        storage_enabled,
    };
    create_market_event_consumer(config).await
}
