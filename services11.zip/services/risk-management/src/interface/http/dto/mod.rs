//! # HTTP DTO 模块
//!
//! 定义风控服务的请求/响应数据结构。

pub mod risk_check;

pub use risk_check::*;
