//! # 策略句柄 (Strategy Handle)
//!
//! 策略实例的句柄，Registry 只管理句柄，不管理策略本身。
//!
//! ## 工程约束
//! - 句柄是轻量的，不包含策略逻辑
//! - 句柄管理生命周期状态
//! - 句柄记录故障历史
//! - 句柄提供执行入口（但不执行策略逻辑）
//!
//! ## 并发保护
//! - 内部状态使用 RwLock 保护
//! - 读操作不阻塞
//! - 写操作（状态转换）互斥

use std::sync::Arc;

use anyhow::{anyhow, Result};
use chrono::{DateTime, Utc};
use parking_lot::RwLock;
use rust_decimal::Decimal;
use serde::{Deserialize, Serialize};
use uuid::Uuid;

use super::failure_record::{FailureHistory, FailureRecord, FailureType};
use super::lifecycle_state::{LifecycleState, LifecycleTransition, LifecycleTransitionError};
use super::strategy_metadata::StrategyMetadata;
use crate::domain::port::strategy_executor_port::StrategyExecutorPort;

/// 策略执行请求
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExecutionRequest {
    /// 请求 ID
    pub request_id: Uuid,
    /// 交易对
    pub symbol: String,
    /// 当前价格
    pub price: Decimal,
    /// 数量
    pub quantity: Decimal,
    /// 时间戳
    pub timestamp: DateTime<Utc>,
    /// 是否买方主动
    pub is_buyer_maker: bool,
    /// 额外上下文
    pub context: Option<serde_json::Value>,
}

impl ExecutionRequest {
    /// 创建执行请求
    pub fn new(symbol: impl Into<String>, price: Decimal, quantity: Decimal) -> Self {
        Self {
            request_id: Uuid::new_v4(),
            symbol: symbol.into(),
            price,
            quantity,
            timestamp: Utc::now(),
            is_buyer_maker: false,
            context: None,
        }
    }
}

/// 策略执行结果
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExecutionResult {
    /// 请求 ID
    pub request_id: Uuid,
    /// 是否产生交易意图
    pub has_intent: bool,
    /// 交易意图（如果有）
    pub intent: Option<TradeIntent>,
    /// 执行耗时（微秒）
    pub execution_time_us: u64,
    /// 错误信息（如果有）
    pub error: Option<String>,
}

/// 交易意图
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TradeIntent {
    /// 意图 ID
    pub id: Uuid,
    /// 策略实例 ID
    pub strategy_id: Uuid,
    /// 交易对
    pub symbol: String,
    /// 方向
    pub side: TradeSide,
    /// 数量
    pub quantity: Decimal,
    /// 价格（限价单）
    pub price: Option<Decimal>,
    /// 订单类型
    pub order_type: OrderType,
    /// 置信度 (0.0 - 1.0)
    pub confidence: f64,
    /// 创建时间
    pub created_at: DateTime<Utc>,
}

/// 交易方向
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum TradeSide {
    Buy,
    Sell,
}

/// 订单类型
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum OrderType {
    Market,
    Limit,
}


/// 策略句柄内部状态（受 RwLock 保护）
#[derive(Debug)]
struct HandleInternalState {
    /// 生命周期状态
    lifecycle: LifecycleState,
    /// 故障历史
    failures: FailureHistory,
    /// 生命周期转换历史
    transitions: Vec<LifecycleTransition>,
    /// 最后执行时间
    last_execution: Option<DateTime<Utc>>,
    /// 执行计数
    execution_count: u64,
    /// 成功计数
    success_count: u64,
}

impl HandleInternalState {
    fn new() -> Self {
        Self {
            lifecycle: LifecycleState::Created,
            failures: FailureHistory::new(),
            transitions: Vec::new(),
            last_execution: None,
            execution_count: 0,
            success_count: 0,
        }
    }
}

/// 策略句柄
///
/// Registry 管理的核心对象，包含：
/// - 策略元数据（不可变）
/// - 生命周期状态（可变，受保护）
/// - 故障历史（可变，受保护）
/// - 执行入口
pub struct StrategyHandle {
    /// 策略元数据（不可变）
    metadata: StrategyMetadata,
    /// 内部状态（受 RwLock 保护）
    state: RwLock<HandleInternalState>,
    /// 策略执行器（由外部注入，通过 Port）
    executor: Arc<dyn StrategyExecutorPort>,
}

impl StrategyHandle {
    /// 创建策略句柄
    pub fn new(metadata: StrategyMetadata, executor: Arc<dyn StrategyExecutorPort>) -> Self {
        Self {
            metadata,
            state: RwLock::new(HandleInternalState::new()),
            executor,
        }
    }

    // =========================================================================
    // 元数据访问（不可变）
    // =========================================================================

    /// 获取实例 ID
    pub fn instance_id(&self) -> Uuid {
        self.metadata.instance_id
    }

    /// 获取元数据引用
    pub fn metadata(&self) -> &StrategyMetadata {
        &self.metadata
    }

    // =========================================================================
    // 生命周期管理
    // =========================================================================

    /// 获取当前生命周期状态
    pub fn lifecycle_state(&self) -> LifecycleState {
        self.state.read().lifecycle
    }

    /// 启动策略
    pub fn start(&self) -> Result<(), LifecycleTransitionError> {
        let mut state = self.state.write();

        if !state.lifecycle.can_start() {
            return Err(LifecycleTransitionError {
                current: state.lifecycle,
                target: LifecycleState::Running,
                reason: "当前状态不允许启动".to_string(),
            });
        }

        let from = state.lifecycle;
        state.lifecycle = LifecycleState::Running;
        state
            .transitions
            .push(LifecycleTransition::new(from, LifecycleState::Running, "start"));

        Ok(())
    }

    /// 暂停策略
    pub fn pause(&self) -> Result<(), LifecycleTransitionError> {
        let mut state = self.state.write();

        if !state.lifecycle.can_pause() {
            return Err(LifecycleTransitionError {
                current: state.lifecycle,
                target: LifecycleState::Paused,
                reason: "当前状态不允许暂停".to_string(),
            });
        }

        let from = state.lifecycle;
        state.lifecycle = LifecycleState::Paused;
        state
            .transitions
            .push(LifecycleTransition::new(from, LifecycleState::Paused, "pause"));

        Ok(())
    }

    /// 恢复策略
    pub fn resume(&self) -> Result<(), LifecycleTransitionError> {
        let mut state = self.state.write();

        if !state.lifecycle.can_resume() {
            return Err(LifecycleTransitionError {
                current: state.lifecycle,
                target: LifecycleState::Running,
                reason: "当前状态不允许恢复".to_string(),
            });
        }

        let from = state.lifecycle;
        state.lifecycle = LifecycleState::Running;
        state
            .transitions
            .push(LifecycleTransition::new(from, LifecycleState::Running, "resume"));

        Ok(())
    }

    /// 停止策略
    pub fn stop(&self) -> Result<(), LifecycleTransitionError> {
        let mut state = self.state.write();

        if !state.lifecycle.can_stop() {
            return Err(LifecycleTransitionError {
                current: state.lifecycle,
                target: LifecycleState::Stopped,
                reason: "当前状态不允许停止".to_string(),
            });
        }

        let from = state.lifecycle;
        state.lifecycle = LifecycleState::Stopped;
        state
            .transitions
            .push(LifecycleTransition::new(from, LifecycleState::Stopped, "stop"));

        Ok(())
    }

    /// 重启策略
    pub fn restart(&self) -> Result<(), LifecycleTransitionError> {
        // 先停止
        {
            let mut state = self.state.write();
            if state.lifecycle.can_stop() {
                let from = state.lifecycle;
                state.lifecycle = LifecycleState::Stopped;
                state.transitions.push(LifecycleTransition::new(
                    from,
                    LifecycleState::Stopped,
                    "restart:stop",
                ));
            }
        }

        // 重置执行器状态
        if let Err(e) = self.executor.reset() {
            let mut state = self.state.write();
            state.lifecycle = LifecycleState::Faulted;
            state.failures.record(
                FailureRecord::new(FailureType::LogicError, format!("重置失败: {}", e))
            );
            return Err(LifecycleTransitionError {
                current: LifecycleState::Faulted,
                target: LifecycleState::Running,
                reason: format!("重置执行器失败: {}", e),
            });
        }

        // 再启动
        {
            let mut state = self.state.write();
            state.lifecycle = LifecycleState::Running;
            state.transitions.push(LifecycleTransition::new(
                LifecycleState::Stopped,
                LifecycleState::Running,
                "restart:start",
            ));
        }

        Ok(())
    }

    /// 标记为故障状态
    pub fn mark_faulted(&self, reason: impl Into<String>) {
        let mut state = self.state.write();
        let from = state.lifecycle;
        state.lifecycle = LifecycleState::Faulted;
        state.transitions.push(LifecycleTransition::new(
            from,
            LifecycleState::Faulted,
            reason,
        ));
    }


    // =========================================================================
    // 执行入口
    // =========================================================================

    /// 执行策略
    ///
    /// 这是 Trading Brain 调用的入口。
    /// 如果策略不在 Running 状态，返回错误。
    pub fn execute(&self, request: &ExecutionRequest) -> Result<ExecutionResult> {
        // 检查生命周期状态
        {
            let state = self.state.read();
            if !state.lifecycle.can_execute() {
                return Err(anyhow!(
                    "策略 {} 当前状态 {} 不允许执行",
                    self.metadata.instance_id,
                    state.lifecycle
                ));
            }
        }

        // 记录执行开始
        let start = std::time::Instant::now();

        // 调用执行器（通过 Port）
        let result = self.executor.execute(request);

        // 更新统计
        {
            let mut state = self.state.write();
            state.last_execution = Some(Utc::now());
            state.execution_count += 1;

            match &result {
                Ok(_) => {
                    state.success_count += 1;
                    state.failures.record_success();
                }
                Err(e) => {
                    state.failures.record(FailureRecord::new(
                        FailureType::LogicError,
                        e.to_string(),
                    ));

                    // 连续故障超过阈值，标记为 Faulted
                    if state.failures.exceeds_threshold(5) {
                        let from = state.lifecycle;
                        state.lifecycle = LifecycleState::Faulted;
                        state.transitions.push(LifecycleTransition::new(
                            from,
                            LifecycleState::Faulted,
                            "连续故障超过阈值",
                        ));
                    }
                }
            }
        }

        // 包装结果，添加执行时间
        match result {
            Ok(mut r) => {
                r.execution_time_us = start.elapsed().as_micros() as u64;
                Ok(r)
            }
            Err(e) => Err(e),
        }
    }

    // =========================================================================
    // 状态查询
    // =========================================================================

    /// 获取故障历史
    pub fn failure_history(&self) -> Vec<FailureRecord> {
        self.state.read().failures.recent().cloned().collect()
    }

    /// 获取连续故障次数
    pub fn consecutive_failures(&self) -> u32 {
        self.state.read().failures.consecutive_failures()
    }

    /// 获取总执行次数
    pub fn execution_count(&self) -> u64 {
        self.state.read().execution_count
    }

    /// 获取成功次数
    pub fn success_count(&self) -> u64 {
        self.state.read().success_count
    }

    /// 获取成功率
    pub fn success_rate(&self) -> f64 {
        let state = self.state.read();
        if state.execution_count == 0 {
            return 0.0;
        }
        state.success_count as f64 / state.execution_count as f64
    }

    /// 获取最后执行时间
    pub fn last_execution(&self) -> Option<DateTime<Utc>> {
        self.state.read().last_execution
    }

    /// 获取生命周期转换历史
    pub fn transition_history(&self) -> Vec<LifecycleTransition> {
        self.state.read().transitions.clone()
    }

    /// 获取策略状态快照
    pub fn state_snapshot(&self) -> Result<serde_json::Value> {
        self.executor.state_snapshot()
    }

    /// 是否可以被移除
    pub fn can_unregister(&self) -> bool {
        let state = self.state.read();
        matches!(
            state.lifecycle,
            LifecycleState::Stopped | LifecycleState::Created
        )
    }
}
