//! Domain models.

/// Strategy entity model.
pub mod strategy;

/// Signal model.
pub mod signal;

/// Strategy configuration models.
pub mod strategy_config;

/// Market type definitions (Spot/Futures).
pub mod market_type;

/// 策略生命周期状态 (Lifecycle State)
pub mod lifecycle_state;

/// 策略故障记录 (Failure Record)
pub mod failure_record;

/// 策略元数据 (Strategy Metadata)
pub mod strategy_metadata;

/// 策略句柄 (Strategy Handle)
pub mod strategy_handle;

/// 策略运行时 (Strategy Runtime)
///
/// 策略作为"被动执行单元"的运行模型。
/// 每个策略实例 = 独立 Task。
pub mod strategy_runtime;
