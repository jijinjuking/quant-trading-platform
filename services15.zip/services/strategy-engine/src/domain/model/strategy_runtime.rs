//! # 策略运行时 (Strategy Runtime)
//!
//! 策略作为"被动执行单元"的运行模型。
//!
//! ## 职责边界（冻结）
//! - 托管单个策略实例的 Task
//! - 通过 channel 接收上游的执行指令
//! - 在单一 Task 内顺序执行策略逻辑
//!
//! ## 严格禁止
//! - ❌ 订阅行情
//! - ❌ 访问 Trading Engine
//! - ❌ 管理多个策略
//! - ❌ 持有全局状态
//! - ❌ activate/deactivate/reset
//!
//! ## 工程约束
//! - 每个策略实例 = 独立 Task
//! - 有明确 shutdown 路径
//! - panic 不影响其他策略
//! - 不允许共享可变状态

use std::sync::Arc;

use anyhow::{anyhow, Result};
use rust_decimal::Decimal;
use serde::{Deserialize, Serialize};
use tokio::sync::{mpsc, oneshot};
use tokio::task::JoinHandle;
use tracing::{error, info, warn};
use uuid::Uuid;

// ============================================================================
// Command 定义（上游发给 Runtime 的指令）
// ============================================================================

/// 执行指令
///
/// 上游通过 channel 发送给 Runtime 的指令。
pub enum RuntimeCommand {
    /// 执行策略计算
    Execute {
        /// 执行上下文
        context: ExecutionContext,
        /// 响应通道
        reply: oneshot::Sender<Result<ExecutionOutput>>,
    },

    /// 关闭 Task
    Shutdown,
}

/// 执行上下文（上游传入的数据）
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExecutionContext {
    /// 请求 ID（用于追踪）
    pub request_id: Uuid,
    /// 交易对
    pub symbol: String,
    /// 当前价格
    pub price: Decimal,
    /// 数量
    pub quantity: Decimal,
    /// 时间戳（毫秒）
    pub timestamp_ms: i64,
    /// 是否买方主动
    pub is_buyer_maker: bool,
}

/// 执行输出（策略计算结果）
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExecutionOutput {
    /// 请求 ID
    pub request_id: Uuid,
    /// 是否产生交易意图
    pub has_intent: bool,
    /// 交易意图
    pub intent: Option<TradeIntent>,
    /// 执行耗时（微秒）
    pub execution_time_us: u64,
}

/// 交易意图
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TradeIntent {
    /// 意图 ID
    pub id: Uuid,
    /// 交易对
    pub symbol: String,
    /// 方向
    pub side: TradeSide,
    /// 数量
    pub quantity: Decimal,
    /// 价格（限价单）
    pub price: Option<Decimal>,
    /// 订单类型
    pub order_type: OrderType,
    /// 置信度 (0.0 - 1.0)
    pub confidence: f64,
}

/// 交易方向
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum TradeSide {
    Buy,
    Sell,
}

/// 订单类型
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum OrderType {
    Market,
    Limit,
}

// ============================================================================
// 策略执行器 Trait（由具体策略实现）
// ============================================================================

/// 策略执行器
///
/// 由具体策略实现，Runtime 持有并调用。
pub trait StrategyExecutor: Send + 'static {
    /// 执行策略计算
    ///
    /// 纯函数，根据上下文返回执行输出。
    /// 不做任何 IO 操作。
    fn execute(&mut self, context: &ExecutionContext) -> Result<ExecutionOutput>;
}

// ============================================================================
// Runtime 句柄（外部持有，用于发送指令）
// ============================================================================

/// Runtime 句柄
///
/// 外部持有此句柄，通过它向 Runtime Task 发送指令。
/// 句柄是轻量的，可以 Clone。
pub struct RuntimeHandle {
    /// 策略实例 ID
    instance_id: Uuid,
    /// 指令发送通道
    command_tx: mpsc::Sender<RuntimeCommand>,
    /// Task 句柄（用于等待退出）
    task_handle: JoinHandle<RuntimeExitReason>,
}

impl RuntimeHandle {
    /// 获取实例 ID
    pub fn instance_id(&self) -> Uuid {
        self.instance_id
    }

    /// 发送执行指令
    ///
    /// 阻塞等待执行结果。
    pub async fn execute(&self, context: ExecutionContext) -> Result<ExecutionOutput> {
        let (reply_tx, reply_rx) = oneshot::channel();

        self.command_tx
            .send(RuntimeCommand::Execute {
                context,
                reply: reply_tx,
            })
            .await
            .map_err(|_| anyhow!("Runtime 已关闭"))?;

        reply_rx.await.map_err(|_| anyhow!("响应通道已关闭"))?
    }

    /// 发送关闭指令
    pub async fn shutdown(&self) -> Result<()> {
        // 忽略发送失败（可能已经关闭）
        let _ = self.command_tx.send(RuntimeCommand::Shutdown).await;
        Ok(())
    }

    /// 等待 Task 退出，返回退出原因
    pub async fn wait(self) -> Result<RuntimeExitReason> {
        self.task_handle
            .await
            .map_err(|e| anyhow!("Task join 失败: {}", e))
    }

    /// 检查 Task 是否已退出
    pub fn is_finished(&self) -> bool {
        self.task_handle.is_finished()
    }

    /// 强制终止 Task
    pub fn abort(&self) {
        self.task_handle.abort();
    }
}

// ============================================================================
// Runtime 退出原因
// ============================================================================

/// Runtime 退出原因
#[derive(Debug, Clone)]
pub enum RuntimeExitReason {
    /// 正常关闭（收到 Shutdown 指令）
    Shutdown,
    /// 通道关闭（上游断开）
    ChannelClosed,
    /// 策略执行 panic
    Panic(String),
}

// ============================================================================
// 启动 Runtime
// ============================================================================

/// 启动策略 Runtime
///
/// 创建独立 Task 托管策略实例。
///
/// # 参数
/// - `instance_id`: 策略实例 ID
/// - `executor`: 策略执行器
/// - `buffer_size`: 指令通道缓冲区大小
///
/// # 返回
/// - `RuntimeHandle`: 用于与 Runtime 通信的句柄
pub fn spawn_runtime<E: StrategyExecutor>(
    instance_id: Uuid,
    executor: E,
    buffer_size: usize,
) -> RuntimeHandle {
    let (command_tx, command_rx) = mpsc::channel(buffer_size);

    let task_handle = tokio::spawn(runtime_task_loop(instance_id, executor, command_rx));

    info!(instance_id = %instance_id, "策略 Runtime 已启动");

    RuntimeHandle {
        instance_id,
        command_tx,
        task_handle,
    }
}

// ============================================================================
// Runtime Task 主循环
// ============================================================================

/// Runtime Task 主循环
async fn runtime_task_loop<E: StrategyExecutor>(
    instance_id: Uuid,
    mut executor: E,
    mut command_rx: mpsc::Receiver<RuntimeCommand>,
) -> RuntimeExitReason {
    info!(instance_id = %instance_id, "Runtime Task 开始运行");

    loop {
        let command = match command_rx.recv().await {
            Some(cmd) => cmd,
            None => {
                // 通道关闭，上游断开
                warn!(instance_id = %instance_id, "指令通道已关闭，Runtime 退出");
                return RuntimeExitReason::ChannelClosed;
            }
        };

        match command {
            RuntimeCommand::Execute { context, reply } => {
                let request_id = context.request_id;
                let start = std::time::Instant::now();

                // 执行策略计算（捕获 panic）
                let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                    executor.execute(&context)
                }));

                match result {
                    Ok(exec_result) => {
                        // 正常执行完成
                        let output = match exec_result {
                            Ok(mut output) => {
                                output.execution_time_us = start.elapsed().as_micros() as u64;
                                Ok(output)
                            }
                            Err(e) => Err(e),
                        };
                        let _ = reply.send(output);
                    }
                    Err(panic_info) => {
                        // 策略执行 panic
                        let panic_msg = extract_panic_message(&panic_info);
                        error!(
                            instance_id = %instance_id,
                            request_id = %request_id,
                            panic = %panic_msg,
                            "策略执行 panic，Runtime 退出"
                        );
                        let _ = reply.send(Err(anyhow!("策略执行 panic: {}", panic_msg)));
                        return RuntimeExitReason::Panic(panic_msg);
                    }
                }
            }

            RuntimeCommand::Shutdown => {
                info!(instance_id = %instance_id, "收到 Shutdown 指令，Runtime 退出");
                return RuntimeExitReason::Shutdown;
            }
        }
    }
}

/// 提取 panic 信息
fn extract_panic_message(panic_info: &Box<dyn std::any::Any + Send>) -> String {
    if let Some(s) = panic_info.downcast_ref::<&str>() {
        s.to_string()
    } else if let Some(s) = panic_info.downcast_ref::<String>() {
        s.clone()
    } else {
        "Unknown panic".to_string()
    }
}

// ============================================================================
// 测试
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    /// 测试用执行器
    struct TestExecutor {
        should_panic: bool,
        should_fail: bool,
    }

    impl TestExecutor {
        fn new() -> Self {
            Self {
                should_panic: false,
                should_fail: false,
            }
        }
    }

    impl StrategyExecutor for TestExecutor {
        fn execute(&mut self, context: &ExecutionContext) -> Result<ExecutionOutput> {
            if self.should_panic {
                panic!("测试 panic");
            }
            if self.should_fail {
                return Err(anyhow!("测试错误"));
            }
            Ok(ExecutionOutput {
                request_id: context.request_id,
                has_intent: false,
                intent: None,
                execution_time_us: 0,
            })
        }
    }

    fn create_test_context() -> ExecutionContext {
        ExecutionContext {
            request_id: Uuid::new_v4(),
            symbol: "BTCUSDT".to_string(),
            price: Decimal::new(50000, 0),
            quantity: Decimal::new(1, 3),
            timestamp_ms: 1704067200000,
            is_buyer_maker: false,
        }
    }

    #[tokio::test]
    async fn test_spawn_and_execute() {
        let instance_id = Uuid::new_v4();
        let executor = TestExecutor::new();
        let handle = spawn_runtime(instance_id, executor, 16);

        // 执行
        let context = create_test_context();
        let result = handle.execute(context).await;
        assert!(result.is_ok());

        // 关闭
        handle.shutdown().await.unwrap();
        let reason = handle.wait().await.unwrap();
        assert!(matches!(reason, RuntimeExitReason::Shutdown));
    }

    #[tokio::test]
    async fn test_execute_error() {
        let instance_id = Uuid::new_v4();
        let mut executor = TestExecutor::new();
        executor.should_fail = true;
        let handle = spawn_runtime(instance_id, executor, 16);

        // 执行应该返回错误
        let context = create_test_context();
        let result = handle.execute(context).await;
        assert!(result.is_err());

        // 但 Runtime 不应该退出
        assert!(!handle.is_finished());

        handle.shutdown().await.unwrap();
    }

    #[tokio::test]
    async fn test_panic_causes_exit() {
        let instance_id = Uuid::new_v4();
        let mut executor = TestExecutor::new();
        executor.should_panic = true;
        let handle = spawn_runtime(instance_id, executor, 16);

        // 执行会触发 panic
        let context = create_test_context();
        let result = handle.execute(context).await;
        assert!(result.is_err());

        // Runtime 应该退出
        let reason = handle.wait().await.unwrap();
        assert!(matches!(reason, RuntimeExitReason::Panic(_)));
    }

    #[tokio::test]
    async fn test_channel_closed() {
        let instance_id = Uuid::new_v4();
        let executor = TestExecutor::new();
        let handle = spawn_runtime(instance_id, executor, 16);

        // 获取 task_handle 但 drop command_tx
        let task_handle = handle.task_handle;
        drop(handle.command_tx);

        // Task 应该因为通道关闭而退出
        let reason = task_handle.await.unwrap();
        assert!(matches!(reason, RuntimeExitReason::ChannelClosed));
    }
}
