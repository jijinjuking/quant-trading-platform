//! # 策略执行器端口 (Strategy Executor Port)
//!
//! 定义策略执行的抽象接口。
//!
//! ## DDD 定位
//! - 这是一个 **Port（端口）**
//! - 定义策略执行的契约
//! - 由 Infrastructure 层实现

use anyhow::Result;
use serde_json::Value;

use crate::domain::model::strategy_handle::{ExecutionRequest, ExecutionResult};

/// 策略执行器端口
///
/// 由具体策略实现，Handle 只持有引用。
/// 这实现了"句柄与逻辑分离"。
pub trait StrategyExecutorPort: Send + Sync {
    /// 执行策略计算
    ///
    /// # 参数
    /// - `request`: 执行请求
    ///
    /// # 返回
    /// - `Ok(ExecutionResult)`: 执行结果
    /// - `Err`: 执行失败
    fn execute(&self, request: &ExecutionRequest) -> Result<ExecutionResult>;

    /// 重置策略状态
    ///
    /// 用于策略重启时清理内部状态。
    fn reset(&self) -> Result<()>;

    /// 获取策略当前状态快照
    ///
    /// 用于调试和监控。
    fn state_snapshot(&self) -> Result<Value>;
}
