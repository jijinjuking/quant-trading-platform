//! # 领域服务 (Domain Services)

/// 信号生成器 - 跨模型规则
pub mod signal_generator;

/// 策略注册表 - 策略句柄管理中心
pub mod strategy_registry;

pub use strategy_registry::{RegistryStats, StrategyQuery, StrategyRegistry};
